#!/usr/bin/env python3
"""
Chess Video Agent
-----------------
Input  : PGN (file or text)
Modes  : silent  → pure board + arrows + eval bar (no talking)
         commentary → same visuals + simple move commentary voice

Usage examples:
  python chess_video_agent.py game.pgn --mode silent --out silent_game.mp4
  python chess_video_agent.py game.pgn --mode commentary --out commentary_game.mp4
  python chess_video_agent.py --pgn "1. e4 e5 2. Nf3 ..." --mode silent
"""

import argparse
import json
import re
import io
import os
import tempfile
from pathlib import Path
from typing import List, Optional, Tuple

import chess
import chess.engine
import chess.pgn
import chess.svg
from PIL import Image
import cairosvg
from moviepy import ImageSequenceClip, AudioFileClip, CompositeAudioClip
import numpy as np

# Optional TTS (edge-tts is free & good quality)
try:
    import edge_tts
    import asyncio
    HAS_TTS = True
except ImportError:
    HAS_TTS = False

STOCKFISH_PATH = None  # set after SCRIPT_DIR via find_stockfish()
DEFAULT_DEPTH = 16
BOARD_SIZE = 720          # px
FPS = 2                   # frames per second for silent (adjust for pace)
MOVE_DURATION = 7.0       # seconds each move is shown
PAUSE_AT_START = 1.5
PAUSE_AT_END = 2.0

# Chess.com style sounds
SCRIPT_DIR = Path(__file__).parent
MOVE_SOUND = SCRIPT_DIR / "chess_move_self.mp3"
CAPTURE_SOUND = SCRIPT_DIR / "chess_capture.mp3"
CHECK_SOUND = SCRIPT_DIR / "chess_move_check.mp3"
BG_MUSIC = SCRIPT_DIR / "bg_music.wav"
BG_VOLUME = 0.85  # clearly audible


def find_stockfish() -> str:
    """Auto-detect Stockfish binary on Windows / macOS / Linux."""
    import platform
    import shutil

    env = os.environ.get("STOCKFISH_PATH") or os.environ.get("STOCKFISH")
    if env and Path(env).exists():
        return str(Path(env).resolve())

    which = shutil.which("stockfish") or shutil.which("stockfish.exe")
    if which:
        return which

    system = platform.system().lower()
    candidates = []

    if system == "windows":
        candidates = [
            Path(r"C:\Program Files\Stockfish\stockfish.exe"),
            Path(r"C:\Program Files (x86)\Stockfish\stockfish.exe"),
            Path(r"C:\stockfish\stockfish.exe"),
            Path.home() / "stockfish" / "stockfish.exe",
            Path.home() / "Downloads" / "stockfish.exe",
            SCRIPT_DIR / "stockfish.exe",
            SCRIPT_DIR / "stockfish" / "stockfish.exe",
        ]
        for base in (Path.home() / "Downloads", Path.home(), SCRIPT_DIR):
            if not base.exists():
                continue
            try:
                candidates.extend(base.glob("stockfish*/stockfish*.exe"))
                candidates.extend(base.glob("stockfish*.exe"))
            except Exception:
                pass
    elif system == "darwin":
        candidates = [
            Path("/opt/homebrew/bin/stockfish"),
            Path("/usr/local/bin/stockfish"),
            Path("/usr/bin/stockfish"),
            SCRIPT_DIR / "stockfish",
        ]
    else:
        candidates = [
            Path("/usr/games/stockfish"),
            Path("/usr/bin/stockfish"),
            Path("/usr/local/bin/stockfish"),
            Path.home() / ".local" / "bin" / "stockfish",
            SCRIPT_DIR / "stockfish",
        ]

    for c in candidates:
        try:
            cp = Path(c)
            if cp.is_file():
                return str(cp.resolve())
        except Exception:
            continue

    raise FileNotFoundError(
        "Stockfish not found.\n"
        "Fix one of:\n"
        "  1) Install Stockfish and ensure `stockfish` is on PATH\n"
        "  2) set STOCKFISH_PATH env to the full binary path\n"
        "  3) place stockfish / stockfish.exe next to this script\n"
        "Windows: https://stockfishchess.org/download/\n"
        "Mac: brew install stockfish\n"
        "Linux: sudo apt install stockfish"
    )


try:
    STOCKFISH_PATH = find_stockfish()
except FileNotFoundError as _sf_err:
    STOCKFISH_PATH = None
    _STOCKFISH_ERROR = str(_sf_err)
else:
    _STOCKFISH_ERROR = None


# Board color themes
BOARD_THEMES = {
    "green": {  # Chess.com classic green
        "square light": "#eeeed2",
        "square dark": "#769656",
        "square light lastmove": "#cdd26a",
        "square dark lastmove": "#aaa23b",
    },
    "brown": {  # Classic wooden
        "square light": "#f0d9b5",
        "square dark": "#b58863",
        "square light lastmove": "#cdd26a",
        "square dark lastmove": "#aaa23b",
    },
    "blue": {
        "square light": "#e0e8f0",
        "square dark": "#4a7c9b",
        "square light lastmove": "#a0c4e0",
        "square dark lastmove": "#3a6a8a",
    },
    "purple": {
        "square light": "#e8e0f0",
        "square dark": "#7b5ea7",
        "square light lastmove": "#c9b3e0",
        "square dark lastmove": "#5a4080",
    },
}
DEFAULT_THEME = "green"


# ---------- Chess.com photo + flag resolver ----------
KNOWN_USERNAMES = {
    "magnus carlsen": "MagnusCarlsen",
    "hikaru nakamura": "Hikaru",
    "hikaru": "Hikaru",
    "fabiano caruana": "FabianoCaruana",
    "ding liren": "DingLiren",
    "ian nepomniachtchi": "lachesisQ",
    "alireza firouzja": "Firouzja2003",
    "wesley so": "GMWSO",
    "levon aronian": "LevAronian",
    "anish giri": "AnishGiri",
    "maxime vachier-lagrave": "LyonCat",
    "maxime vachier lagrave": "LyonCat",
    "viswanathan anand": "Viswanathananand",
    "gukesh d": "GukeshDommaraju",
    "gukesh": "GukeshDommaraju",
    "praggnanandhaa": "rpragchess",
    "nodirbek abdusattorov": "ChessWarrior7197",
    "richard rapport": "rapport67",
    "shakhriyar mamedyarov": "LordShakh",
    "sergey karjakin": "SergeyKarjakin",
    "vladimir kramnik": "VladimirKramnik",
    "garry kasparov": "GarryKasparov",
    "bobby fischer": "BobbyFischer",
}

def _slug_candidates(name: str):
    n = (name or "").strip()
    if not n:
        return []
    cands = []
    key = n.lower()
    if key in KNOWN_USERNAMES:
        cands.append(KNOWN_USERNAMES[key])
    # Remove titles
    for t in ("GM ", "IM ", "FM ", "WGM ", "WIM ", "CM ", "WCM "):
        if n.upper().startswith(t.strip() + " ") or n.startswith(t):
            n = n[len(t):].strip()
    parts = re.sub(r"[^A-Za-z0-9 ]", "", n).split()
    if parts:
        cands.append("".join(parts))          # MagnusCarlsen
        cands.append("".join(parts).lower())  # magnuscarlsen
        if len(parts) >= 2:
            cands.append(parts[-1])           # Carlsen / Nakamura style sometimes
            cands.append(parts[0] + parts[-1])
    # unique preserve order
    seen = set()
    out = []
    for c in cands:
        if c and c.lower() not in seen:
            seen.add(c.lower())
            out.append(c)
    return out


def fetch_chesscom_profile(username: str) -> Optional[dict]:
    import urllib.request
    url = f"https://api.chess.com/pub/player/{username}"
    req = urllib.request.Request(url, headers={"User-Agent": "ChessVideoAgent/1.0 (educational)"})
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None


def resolve_player_assets(display_name: str) -> tuple:
    """
    Returns (photo_path, flag_path) using Chess.com avatar + country flag.
    Caches under SCRIPT_DIR/players and SCRIPT_DIR/flags.
    """
    import urllib.request
    import re as _re

    players_dir = SCRIPT_DIR / "players"
    flags_dir = SCRIPT_DIR / "flags"
    players_dir.mkdir(exist_ok=True)
    flags_dir.mkdir(exist_ok=True)

    profile = None
    used_user = None
    for cand in _slug_candidates(display_name):
        profile = fetch_chesscom_profile(cand)
        if profile and profile.get("avatar"):
            used_user = cand
            break

    photo_path = None
    flag_path = None

    if profile:
        # Avatar
        avatar_url = profile.get("avatar")
        if avatar_url:
            safe = _re.sub(r"[^a-zA-Z0-9_-]", "_", (used_user or display_name).lower())[:40]
            dest = players_dir / f"{safe}.jpg"
            if not dest.exists() or dest.stat().st_size < 500:
                try:
                    req = urllib.request.Request(avatar_url, headers={"User-Agent": "ChessVideoAgent/1.0"})
                    with urllib.request.urlopen(req, timeout=10) as r:
                        dest.write_bytes(r.read())
                except Exception as e:
                    print(f"  avatar download failed for {display_name}: {e}")
            if dest.exists() and dest.stat().st_size > 500:
                photo_path = str(dest)

        # Country → flagcdn
        country_url = profile.get("country") or ""
        code = country_url.rstrip("/").split("/")[-1].lower() if country_url else ""
        if code and len(code) == 2:
            fdest = flags_dir / f"{code}.png"
            if not fdest.exists() or fdest.stat().st_size < 50:
                try:
                    flag_url = f"https://flagcdn.com/w80/{code}.png"
                    req = urllib.request.Request(flag_url, headers={"User-Agent": "ChessVideoAgent/1.0"})
                    with urllib.request.urlopen(req, timeout=8) as r:
                        fdest.write_bytes(r.read())
                except Exception as e:
                    print(f"  flag download failed {code}: {e}")
            if fdest.exists() and fdest.stat().st_size > 50:
                flag_path = str(fdest)

    return photo_path, flag_path



# Lichess usernames for top players
LICHESS_USERNAMES = {
    "magnus carlsen": "DrNykterstein",
    "magnuscarlsen": "DrNykterstein",
    "hikaru nakamura": "Hikaru",
    "hikaru": "Hikaru",
    "fabiano caruana": "FabianoCaruana",
    "ding liren": "DingLiren",
    "ian nepomniachtchi": "lachesisQ",
    "alireza firouzja": "alirezaf2003",
    "gukesh": "GukeshDommaraju",
    "gukesh d": "GukeshDommaraju",
    "praggnanandhaa": "rpragchess",
    "anish giri": "AnishGiri",
    "wesley so": "penguingim1",
}

# Real name (FIDE/offline) → platform username
# Online archives use username; video labels should prefer real/display name.
REAL_NAME_TO_CHESSCOM = {
    "magnus carlsen": "MagnusCarlsen",
    "hikaru nakamura": "Hikaru",
    "fabiano caruana": "FabianoCaruana",
    "ding liren": "DingLiren",
    "ian nepomniachtchi": "lachesisQ",
    "alireza firouzja": "Firouzja2003",
    "wesley so": "GMWSO",
    "levon aronian": "LevAronian",
    "anish giri": "AnishGiri",
    "maxime vachier-lagrave": "LyonCat",
    "maxime vachier lagrave": "LyonCat",
    "viswanathan anand": "Viswanathananand",
    "gukesh d": "GukeshDommaraju",
    "gukesh": "GukeshDommaraju",
    "d gukesh": "GukeshDommaraju",
    "praggnanandhaa r": "rpragchess",
    "praggnanandhaa": "rpragchess",
    "r praggnanandhaa": "rpragchess",
    "nodirbek abdusattorov": "ChessWarrior7197",
    "richard rapport": "rapport67",
    "shakhriyar mamedyarov": "LordShakh",
    "sergey karjakin": "SergeyKarjakin",
    "vladimir kramnik": "VladimirKramnik",
    "garry kasparov": "GarryKasparov",
    "hans niemann": "HansNiemann",
    "nihal sarin": "nihalsarin",
    "vidit gujrathi": "viditchess",
    "arjun erigaisi": "ArjunErigaisi",
    "dominic fridman": "FairChess_on_YouTube",
}

REAL_NAME_TO_LICHESS = {
    "magnus carlsen": "DrNykterstein",
    "hikaru nakamura": "Hikaru",
    "fabiano caruana": "FabianoCaruana",
    "ding liren": "DingLiren",
    "ian nepomniachtchi": "lachesisQ",
    "alireza firouzja": "alirezaf2003",
    "gukesh": "GukeshDommaraju",
    "gukesh d": "GukeshDommaraju",
    "praggnanandhaa": "rpragchess",
    "anish giri": "AnishGiri",
    "wesley so": "penguingim1",
    "hans niemann": "HansNiemann",
    "nihal sarin": "nihalsarin",
    "arjun erigaisi": "ArjunErigaisi",
}

# Reverse: username → nice display name
CHESSCOM_TO_DISPLAY = {v.lower(): k.title() for k, v in REAL_NAME_TO_CHESSCOM.items()}
CHESSCOM_TO_DISPLAY.update({
    "magnuscarlsen": "Magnus Carlsen",
    "hikaru": "Hikaru Nakamura",
    "firouzja2003": "Alireza Firouzja",
    "gukeshdommaraju": "Gukesh D",
    "rpragchess": "Praggnanandhaa R",
    "lachesisq": "Ian Nepomniachtchi",
    "gmwso": "Wesley So",
    "lyoncat": "Maxime Vachier-Lagrave",
})
LICHESS_TO_DISPLAY = {v.lower(): k.title() for k, v in REAL_NAME_TO_LICHESS.items()}
LICHESS_TO_DISPLAY.update({
    "drnykterstein": "Magnus Carlsen",
    "hikaru": "Hikaru Nakamura",
    "alirezaf2003": "Alireza Firouzja",
})


def display_name_for(username_or_name: str, platform: str = "chesscom") -> str:
    """Prefer real/FIDE-style name over raw online username."""
    raw = (username_or_name or "").strip()
    if not raw:
        return "Unknown"
    key = raw.lower()
    # already a real name?
    if " " in raw and key in REAL_NAME_TO_CHESSCOM:
        return raw.title() if raw.islower() else raw
    if platform == "lichess":
        if key in LICHESS_TO_DISPLAY:
            return LICHESS_TO_DISPLAY[key]
    else:
        if key in CHESSCOM_TO_DISPLAY:
            return CHESSCOM_TO_DISPLAY[key]
    # Chess.com profile may have "name" field — try fetch
    try:
        if platform != "lichess":
            prof = fetch_chesscom_profile(raw)
            if prof and prof.get("name"):
                return prof["name"]
    except Exception:
        pass
    return raw


TOURNAMENT_EVENT_HINTS = (
    "tournament", "championship", "candidates", "olympiad", "fide",
    "grand prix", "grand swiss", "world cup", "titled", "swiss",
    "open", "invitational", "masters", "superbet", "norway chess",
    "tata steel", "sinquefield", "rapid & blitz", "speed chess",
)


def _api_get_json(url: str, headers: Optional[dict] = None):
    import urllib.request
    h = {"User-Agent": "ChessVideoAgent/1.0 (educational)"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode())


def _pgn_result(pgn: str) -> Optional[str]:
    for line in pgn.splitlines():
        if line.startswith("[Result "):
            try:
                return line.split('"')[1]
            except Exception:
                return None
    return None


def _pgn_event(pgn: str) -> str:
    for line in pgn.splitlines():
        if line.startswith("[Event "):
            try:
                return line.split('"')[1]
            except Exception:
                return ""
    return ""


def _is_tournament_event(event: str, time_class: str = "") -> bool:
    e = (event or "").lower()
    if not e:
        return False
    if "live chess" in e:
        return False
    if any(h in e for h in TOURNAMENT_EVENT_HINTS):
        return True
    # daily often used for longer/event games on chess.com
    if time_class == "daily" and e and e != "live chess":
        return True
    # Generic non-live named event
    if e not in ("live chess", "chess.com", "online"):
        if len(e) > 8:
            return True
    return False


def resolve_chesscom_username(player_query: str) -> str:
    key = (player_query or "").strip().lower()
    if key in REAL_NAME_TO_CHESSCOM:
        return REAL_NAME_TO_CHESSCOM[key]
    if key in KNOWN_USERNAMES:
        return KNOWN_USERNAMES[key]
    for cand in _slug_candidates(player_query):
        prof = fetch_chesscom_profile(cand)
        if prof and prof.get("avatar"):
            return cand
    return player_query.replace(" ", "")


def resolve_lichess_username(player_query: str) -> str:
    key = (player_query or "").strip().lower()
    if key in REAL_NAME_TO_LICHESS:
        return REAL_NAME_TO_LICHESS[key]
    if key in LICHESS_USERNAMES:
        return LICHESS_USERNAMES[key]
    for cand in _slug_candidates(player_query):
        return cand
    return player_query.replace(" ", "")


def fetch_chesscom_games(username: str, max_months: int = 8):
    archives = _api_get_json(f"https://api.chess.com/pub/player/{username}/games/archives")
    months = list(reversed(archives.get("archives", [])))[:max_months]
    all_games = []
    for month_url in months:
        try:
            data = _api_get_json(month_url)
            all_games.extend(data.get("games", []))
        except Exception as e:
            print(f"  month skip {month_url}: {e}")
    # newest first
    all_games.sort(key=lambda g: g.get("end_time", 0), reverse=True)
    return all_games


def fetch_latest_decisive_pgn(
    player_query: str,
    source: str = "chesscom",
    max_months: int = 8,
) -> tuple:
    """
    source:
      chesscom / online  → Chess.com live online games (blitz/rapid/bullet)
      lichess            → Lichess rated games
      tournament / fide  → Chess.com games that look like FIDE/OTB/titled events
    Returns (pgn_text, meta_dict)
    """
    source = (source or "chesscom").lower().strip()
    # Normalize aliases — keep online and offline strictly separate
    if source in ("online", "live", "chess.com", "chesscom-online"):
        source = "chesscom"          # ONLINE only
    elif source in ("fide", "otb", "event", "offline", "tournament"):
        source = "tournament"        # OFFLINE / FIDE-style only
    elif source == "lichess":
        source = "lichess"           # ONLINE (Lichess platform)
    else:
        source = source

    # ---------- Lichess ----------
    if source == "lichess":
        import time
        import urllib.request
        uname = resolve_lichess_username(player_query)
        print(f"  Lichess user: {uname}")
        time.sleep(1.5)  # respect rate limits
        url = (
            f"https://lichess.org/api/games/user/{uname}"
            f"?max=30&rated=true&moves=true&pgnInJson=true&sort=dateDesc"
        )
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "ChessVideoAgent/1.0 (educational)",
                "Accept": "application/x-ndjson",
            },
        )
        last_err = None
        raw = ""
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req, timeout=30) as r:
                    raw = r.read().decode()
                break
            except Exception as e:
                last_err = e
                print(f"  Lichess retry {attempt+1}: {e}")
                time.sleep(3 * (attempt + 1))
        else:
            raise last_err
        for line in raw.splitlines():
            if not line.strip():
                continue
            g = json.loads(line)
            winner = g.get("winner")  # white / black
            status = g.get("status")
            if status in ("draw", "stalemate") or not winner:
                continue
            # Build simple PGN from json if pgn field present
            pgn = g.get("pgn")
            if not pgn:
                continue
            result = _pgn_result(pgn) or ("1-0" if winner == "white" else "0-1")
            players = g.get("players") or {}
            white_u = ((players.get("white") or {}).get("user") or {}).get("name", "?")
            black_u = ((players.get("black") or {}).get("user") or {}).get("name", "?")
            meta = {
                "result": result,
                "white": white_u,
                "black": black_u,
                "url": f"https://lichess.org/{g.get('id', '')}",
                "time_class": g.get("speed", ""),
                "source": "lichess",
                "event": _pgn_event(pgn),
            }
            return pgn, meta
        raise ValueError(f"No decisive rated game found on Lichess for {uname}")

    # ---------- Chess.com (online or tournament) ----------
    uname = resolve_chesscom_username(player_query)
    print(f"  Chess.com user: {uname}")
    games = fetch_chesscom_games(uname, max_months=max_months)

    for g in games:
        pgn = g.get("pgn") or ""
        if not pgn.strip():
            continue
        result = _pgn_result(pgn)
        if result not in ("1-0", "0-1"):
            continue
        event = _pgn_event(pgn)
        time_class = g.get("time_class") or ""

        if source == "chesscom":
            # ONLINE ONLY — Live Chess / blitz / rapid / bullet
            # Never treat FIDE/OTB-style events as online
            if _is_tournament_event(event, time_class):
                continue
            if time_class not in ("blitz", "rapid", "bullet", "lightning") and "Live Chess" not in event:
                # allow if clearly live
                if "live" not in event.lower():
                    continue
        elif source in ("tournament", "offline", "fide"):
            # OFFLINE / FIDE / titled events ONLY — never Live Chess online play
            if not _is_tournament_event(event, time_class):
                continue
            if "Live Chess" in event:
                continue
        else:
            continue

        white_u = (g.get("white") or {}).get("username", "?")
        black_u = (g.get("black") or {}).get("username", "?")
        meta = {
            "result": result,
            "white": white_u,
            "black": black_u,
            "url": g.get("url", ""),
            "time_class": time_class,
            "source": source,
            "event": event,
        }
        return pgn, meta

    # STRICT: no cross-fallback between online and offline sources
    if source in ("tournament", "offline", "fide"):
        raise ValueError(
            "No OFFLINE/FIDE-style decisive game found in Chess.com archives. "
            "Pure OTB FIDE games are usually not in live archives. "
            "Paste official PGN via file or --pgn. Online Live Chess is never used for offline source."
        )
    raise ValueError(
        f"No ONLINE decisive game found for {uname} (source={source}) in last {max_months} months."
    )




def load_game(pgn_source: str) -> chess.pgn.Game:
    """Load game from file path or raw PGN string."""
    if os.path.isfile(pgn_source):
        with open(pgn_source, encoding="utf-8") as f:
            game = chess.pgn.read_game(f)
    else:
        game = chess.pgn.read_game(io.StringIO(pgn_source))
    if game is None:
        raise ValueError("Could not parse PGN")
    return game


def analyze_game(game: chess.pgn.Game, depth: int = DEFAULT_DEPTH) -> List[dict]:
    """
    Run Stockfish on every position.
    Returns list of dicts with: fen, move, eval_cp, best_move, is_check, last_move
    """
    path = STOCKFISH_PATH or os.environ.get("STOCKFISH_PATH") or os.environ.get("STOCKFISH")
    if not path or not Path(path).exists():
        # last-chance detect
        try:
            path = find_stockfish()
        except FileNotFoundError as e:
            raise FileNotFoundError(_STOCKFISH_ERROR or str(e)) from e
    engine = chess.engine.SimpleEngine.popen_uci(path)
    board = game.board()
    analysis = []

    # Starting position
    info = engine.analyse(board, chess.engine.Limit(depth=depth))
    score = info["score"].white()
    eval_cp = score.score(mate_score=10000) if score is not None else 0
    analysis.append({
        "fen": board.fen(),
        "move": None,
        "san": None,
        "eval_cp": eval_cp,
        "best_move": info.get("pv", [None])[0],
        "is_check": board.is_check(),
        "last_move": None,
    })

    for node in game.mainline():
        move = node.move
        san = board.san(move)
        board.push(move)

        info = engine.analyse(board, chess.engine.Limit(depth=depth))
        score = info["score"].white()
        eval_cp = score.score(mate_score=10000) if score is not None else 0

        analysis.append({
            "fen": board.fen(),
            "move": move,
            "san": san,
            "eval_cp": eval_cp,
            "best_move": info.get("pv", [None])[0],
            "is_check": board.is_check(),
            "last_move": move,
        })

    engine.quit()
    return analysis


def eval_to_bar_color(eval_cp: int) -> str:
    """Simple color helper (not used directly in SVG)."""
    if eval_cp > 150:
        return "#4CAF50"
    if eval_cp < -150:
        return "#F44336"
    return "#9E9E9E"


def render_frame(
    fen: str,
    last_move: Optional[chess.Move] = None,
    best_move: Optional[chess.Move] = None,
    is_check: bool = False,
    size: int = BOARD_SIZE,
    theme: str = DEFAULT_THEME,
    white_name: str = "White",
    black_name: str = "Black",
    white_photo: Optional[str] = None,
    black_photo: Optional[str] = None,
    white_flag: Optional[str] = None,
    black_flag: Optional[str] = None,
    eval_cp: Optional[int] = None,
    opening_text: Optional[str] = None,
    show_eval_bar: bool = True,
    clock_text: Optional[str] = None,
) -> Image.Image:
    """
    Board + arrows + player names + optional photo + country flag.
    Black info on top bar, White info on bottom bar.
    """
    from PIL import ImageDraw, ImageFont, ImageOps

    board = chess.Board(fen)
    arrows = []
    if last_move:
        arrows.append(chess.svg.Arrow(last_move.from_square, last_move.to_square, color="#00FF44"))
    if best_move and (last_move is None or best_move != last_move):
        arrows.append(chess.svg.Arrow(best_move.from_square, best_move.to_square, color="#00AAFF"))
    check_square = board.king(board.turn) if is_check else None
    colors = BOARD_THEMES.get(theme, BOARD_THEMES[DEFAULT_THEME])

    svg_data = chess.svg.board(
        board=board, lastmove=last_move, check=check_square,
        arrows=arrows, size=size, coordinates=True, colors=colors,
    )
    png_bytes = cairosvg.svg2png(bytestring=svg_data.encode("utf-8"))
    board_img = Image.open(io.BytesIO(png_bytes)).convert("RGBA")

    label_h = 64
    total_h = board_img.height + 2 * label_h
    total_w = board_img.width
    canvas = Image.new("RGBA", (total_w, total_h), (28, 28, 28, 255))
    canvas.paste(board_img, (0, label_h))
    draw = ImageDraw.Draw(canvas)

    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
    except Exception:
        font = ImageFont.load_default()

    def _round_photo(path, box=52):
        if not path or not Path(path).exists():
            return None
        try:
            im = Image.open(path).convert("RGBA")
            im = ImageOps.fit(im, (box, box), centering=(0.5, 0.5))
            mask = Image.new("L", (box, box), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, box, box), fill=255)
            out = Image.new("RGBA", (box, box), (0, 0, 0, 0))
            out.paste(im, (0, 0))
            out.putalpha(mask)
            return out
        except Exception:
            return None

    def _flag(path, h=28):
        if not path or not Path(path).exists():
            return None
        try:
            im = Image.open(path).convert("RGBA")
            w = int(im.width * (h / im.height))
            return im.resize((max(w, 1), h), Image.LANCZOS)
        except Exception:
            return None

    def draw_player_bar(y0, name, photo_path, flag_path):
        draw.rectangle([0, y0, total_w, y0 + label_h], fill=(36, 36, 36, 255))
        x = 12
        photo = _round_photo(photo_path, 52)
        if photo:
            canvas.paste(photo, (x, y0 + (label_h - 52) // 2), photo)
            x += 60
        flag = _flag(flag_path, 26)
        if flag:
            canvas.paste(flag, (x, y0 + (label_h - 26) // 2), flag)
            x += flag.width + 10
        nm = (name or "")[:26]
        bbox = draw.textbbox((0, 0), nm, font=font)
        th = bbox[3] - bbox[1]
        draw.text((x, y0 + (label_h - th) // 2 - 2), nm, fill=(245, 245, 245, 255), font=font)

    # Top = Black, Bottom = White
    draw_player_bar(0, black_name, black_photo, black_flag)
    draw_player_bar(label_h + board_img.height, white_name, white_photo, white_flag)

    # --- Eval bar (right side of board area) ---
    if show_eval_bar and eval_cp is not None:
        bar_w = 18
        board_top = label_h
        board_h = board_img.height
        # expand canvas for bar
        new_w = total_w + bar_w + 8
        expanded = Image.new("RGBA", (new_w, total_h), (28, 28, 28, 255))
        expanded.paste(canvas, (0, 0))
        canvas = expanded
        draw = ImageDraw.Draw(canvas)
        # eval from white POV: + = white better (bar fill from bottom)
        # clamp mate scores
        e = max(-800, min(800, int(eval_cp)))
        # map -800..800 → 0..1 white share from bottom
        white_share = (e + 800) / 1600.0
        white_h = int(board_h * white_share)
        black_h = board_h - white_h
        bx = total_w + 4
        # black advantage (top)
        draw.rectangle([bx, board_top, bx + bar_w, board_top + black_h], fill=(40, 40, 40))
        # white advantage (bottom)
        draw.rectangle([bx, board_top + black_h, bx + bar_w, board_top + board_h], fill=(235, 235, 235))
        # mid line
        mid = board_top + board_h // 2
        draw.line([(bx, mid), (bx + bar_w, mid)], fill=(120, 120, 120), width=1)

    # --- Opening banner (top overlay) ---
    if opening_text:
        try:
            ofont = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
        except Exception:
            ofont = font
        pad = 8
        bb = draw.textbbox((0, 0), opening_text, font=ofont)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        ox = (canvas.width - tw) // 2
        oy = 8
        draw.rounded_rectangle(
            [ox - pad, oy - 4, ox + tw + pad, oy + th + 6],
            radius=6, fill=(20, 20, 20, 220),
        )
        draw.text((ox, oy), opening_text, font=ofont, fill=(255, 220, 80))


    # --- Clock / time-control badge ---
    if clock_text:
        try:
            cfont = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16)
        except Exception:
            cfont = font
        label = str(clock_text)[:24]
        bb = draw.textbbox((0, 0), label, font=cfont)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        # right corner
        cx = canvas.width - tw - 18
        cy = canvas.height - th - 16
        draw.rounded_rectangle([cx - 8, cy - 4, cx + tw + 8, cy + th + 6], radius=6, fill=(30, 30, 40, 230))
        draw.text((cx, cy), label, font=cfont, fill=(200, 200, 210))


    return canvas



def _is_capture(move: Optional[chess.Move], fen_before: str) -> bool:
    """Check if the move was a capture."""
    if move is None:
        return False
    board = chess.Board(fen_before)
    return board.is_capture(move)



def opening_label_from_game(game: chess.pgn.Game) -> str:
    eco = (game.headers.get("ECO") or "").strip()
    opening = (game.headers.get("Opening") or "").strip()
    ECO_NAMES = {
        "C41": "Philidor Defense", "C20": "King Pawn", "B20": "Sicilian Defense",
        "C00": "French Defense", "C60": "Ruy Lopez", "B90": "Najdorf Sicilian",
        "D00": "Queen Pawn", "E00": "Indian / Catalan", "A00": "Uncommon Opening",
        "C50": "Italian Game", "B01": "Scandinavian", "C42": "Petrov Defense",
    }
    if opening and opening not in ("?", "-"):
        return opening[:42]
    if eco:
        name = ECO_NAMES.get(eco[:3], "")
        return f"{name} ({eco})" if name else f"ECO {eco}"
    return ""


def find_climax_window(analysis: List[dict], window_moves: int = 12) -> tuple:
    """Return (start_idx, end_idx) into analysis for shorts climax clip."""
    n = len(analysis)
    if n <= 2:
        return 0, n
    # Prefer mate / final check sequence
    for i in range(n - 1, 0, -1):
        if analysis[i].get("is_check"):
            start = max(0, i - window_moves)
            return start, n
    # Max eval swing between consecutive positions
    best_i, best_swing = 1, -1
    for i in range(1, n):
        a = analysis[i - 1].get("eval_cp") or 0
        b = analysis[i].get("eval_cp") or 0
        swing = abs(b - a)
        if swing > best_swing:
            best_swing, best_i = swing, i
    start = max(0, best_i - window_moves // 2)
    end = min(n, start + window_moves + 1)
    if end - start < 6:
        start = max(0, n - window_moves - 1)
        end = n
    return start, end


def create_shorts_clip(
    analysis: List[dict],
    output_path: str,
    move_duration: float = 2.0,
    theme: str = DEFAULT_THEME,
    white_name: str = "White",
    black_name: str = "Black",
    white_photo: Optional[str] = None,
    black_photo: Optional[str] = None,
    white_flag: Optional[str] = None,
    black_flag: Optional[str] = None,
    window_moves: int = 12,
) -> str:
    """Climax-only silent video for Shorts (~30-60s depending on window)."""
    start, end = find_climax_window(analysis, window_moves=window_moves)
    sub = analysis[start:end]
    if len(sub) < 2:
        sub = analysis
    print(f"   Shorts clip moves {start}..{end-1} ({len(sub)-1} moves)")
    return create_silent_video(
        sub, output_path, move_duration=move_duration, theme=theme,
        white_name=white_name, black_name=black_name,
        white_photo=white_photo, black_photo=black_photo,
        white_flag=white_flag, black_flag=black_flag,
        opening_text=None, show_opening_seconds=0,
    )



def create_silent_video(
    analysis: List[dict],
    output_path: str,
    fps: int = FPS,
    move_duration: float = MOVE_DURATION,
    theme: str = DEFAULT_THEME,
    white_name: str = "White",
    black_name: str = "Black",
    white_photo: Optional[str] = None,
    black_photo: Optional[str] = None,
    white_flag: Optional[str] = None,
    black_flag: Optional[str] = None,
    opening_text: Optional[str] = None,
    show_opening_seconds: float = 4.0,
    show_eval_bar: bool = True,
    clock_text: Optional[str] = None,
    bg_music: bool = False,
    zoom_key_moments: bool = True,
    watermark: Optional[str] = None,
    intro_card: bool = True,
    elo_badge: Optional[str] = None,
    next_trap: Optional[str] = None,
    viral_hook: Optional[str] = None,
    refutation_key: Optional[str] = None,
) -> str:
    """Build video with board + arrows + Chess.com style move sounds + player names."""
    frames = []
    durations = []
    audio_clips = []
    current_time = 0.0
    key_indices = set()
    if zoom_key_moments:
        for m in detect_key_moments(analysis):
            if m.get("type") in ("brilliant", "blunder", "mate", "check"):
                key_indices.add(m["index"])

    def _zoom(img, factor=1.12):
        """Slight zoom toward center for key moments."""
        from PIL import Image as _Image
        if not isinstance(img, _Image.Image):
            return img
        w, h = img.size
        nw, nh = int(w * factor), int(h * factor)
        z = img.resize((nw, nh), _Image.LANCZOS)
        left, top = (nw - w) // 2, (nh - h) // 2
        return z.crop((left, top, left + w, top + h))

    # Starting position (longer pause, no sound)
    def _ot(elapsed):
        if opening_text and elapsed < show_opening_seconds:
            return opening_text
        return None

    img = render_frame(
        analysis[0]["fen"],
        last_move=None,
        best_move=analysis[0].get("best_move"),
        is_check=analysis[0].get("is_check", False),
        theme=theme,
        white_name=white_name,
        black_name=black_name,
        white_photo=white_photo,
        black_photo=black_photo,
        white_flag=white_flag,
        black_flag=black_flag,
        eval_cp=analysis[0].get("eval_cp"),
        opening_text=_ot(0),
        show_eval_bar=show_eval_bar,
        clock_text=clock_text,
    )
    if watermark:
        img = apply_watermark(img.convert("RGB"), watermark)
    else:
        img = img.convert("RGB")
    if elo_badge:
        img = apply_elo_badge(img, elo_badge)
    # Intro card same size as board frames
    if intro_card:
        try:
            intro = make_intro_card(
                white_name, black_name,
                opening=opening_text or "",
                clock_text=clock_text or "",
                size=img.size,
            )
            if watermark:
                intro = apply_watermark(intro, watermark)
            frames.append(np.array(intro.convert("RGB")))
            durations.append(2.2)
            current_time += 2.2
        except Exception as e:
            print(f"Intro card skipped: {e}")
    if viral_hook:
        try:
            hc = make_viral_hook_card(viral_hook, subtitle="Watch till the end", size=img.size)
            if watermark:
                hc = apply_watermark(hc, watermark)
            frames.append(np.array(hc.convert("RGB")))
            durations.append(1.8)
            current_time += 1.8
        except Exception as e:
            print(f"Viral hook skipped: {e}")
    frames.append(np.array(img))
    durations.append(PAUSE_AT_START)
    current_time += PAUSE_AT_START

    for i, pos in enumerate(analysis[1:], 1):
        img = render_frame(
            pos["fen"],
            last_move=pos.get("last_move"),
            best_move=pos.get("best_move"),
            is_check=pos.get("is_check", False),
            theme=theme,
            white_name=white_name,
            black_name=black_name,
            white_photo=white_photo,
            black_photo=black_photo,
            white_flag=white_flag,
            black_flag=black_flag,
            eval_cp=pos.get("eval_cp"),
            opening_text=_ot(current_time),
            show_eval_bar=show_eval_bar,
            clock_text=clock_text,
        )
        if i in key_indices:
            img = _zoom(img)
        if watermark:
            img = apply_watermark(img.convert("RGB") if hasattr(img, 'convert') else img, watermark)
        else:
            img = img.convert("RGB") if hasattr(img, 'convert') else img
        if elo_badge:
            img = apply_elo_badge(img, elo_badge)
        frames.append(np.array(img))
        dur = move_duration + (0.8 if i == len(analysis) - 1 else 0)
        if i in key_indices:
            dur += 0.6
        durations.append(dur)

        # Chess.com style sound
        move = pos.get("last_move")
        fen_before = analysis[i - 1]["fen"]
        is_cap = _is_capture(move, fen_before)
        is_chk = pos.get("is_check", False)

        if is_chk and CHECK_SOUND.exists():
            sound_path = CHECK_SOUND
        elif is_cap and CAPTURE_SOUND.exists():
            sound_path = CAPTURE_SOUND
        else:
            sound_path = MOVE_SOUND

        if sound_path.exists():
            try:
                ac = AudioFileClip(str(sound_path))
                # Use full short duration of the sound
                ac = ac.with_duration(min(0.35, ac.duration)).with_start(current_time)
                audio_clips.append(ac)
            except Exception as e:
                print(f"Sound load failed: {e}")

        current_time += dur

    # Refutation branch
    if refutation_key:
        h, w = frames[0].shape[0], frames[0].shape[1]
        current_time = append_refutation_segment(
            frames, durations, audio_clips, current_time,
            refutation_key, theme, move_duration, watermark, size=(w, h),
        )

    # Extra end pause
    try:
        end = make_end_screen(
            white_name, black_name,
            size=(frames[0].shape[1], frames[0].shape[0]),
            next_trap=next_trap or "",
        )
        frames.append(np.array(end.convert("RGB")))
        durations.append(max(2.5, PAUSE_AT_END + 1.0))
    except Exception as e:
        print(f"End screen skipped: {e}")
        durations[-1] += PAUSE_AT_END


    clip = ImageSequenceClip(frames, durations=durations)
    total_duration = sum(durations)

    final_audio = None
    if audio_clips:
        final_audio = CompositeAudioClip(audio_clips)

    # Optional soft looping background music bed
    if bg_music:
        music_file = None
        for cand in (SCRIPT_DIR / "bg_soft.wav", SCRIPT_DIR / "bg_music.wav", BG_MUSIC):
            if cand and Path(cand).exists():
                music_file = Path(cand)
                break
        if music_file:
            try:
                bg = AudioFileClip(str(music_file)).with_volume_scaled(0.10)
                from moviepy import concatenate_audioclips
                loops = int(total_duration / max(0.1, bg.duration)) + 1
                bg_loop = concatenate_audioclips([bg] * loops).subclipped(0, total_duration)
                if final_audio:
                    final_audio = CompositeAudioClip([final_audio, bg_loop])
                else:
                    final_audio = bg_loop
            except Exception as e:
                print(f"BG music failed: {e}")

    if final_audio:
        clip = clip.with_audio(final_audio)

    clip.write_videofile(
        output_path,
        fps=fps,
        codec="libx264",
        audio_codec="aac" if final_audio else None,
        logger=None,
    )
    clip.close()
    return output_path


async def _generate_tts(text: str, voice: str = "en-US-ChristopherNeural") -> str:
    """Generate temporary mp3 with edge-tts."""
    communicate = edge_tts.Communicate(text, voice, rate="+15%")
    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    await communicate.save(tmp.name)
    return tmp.name


def create_commentary_video(
    analysis: List[dict],
    output_path: str,
    fps: int = FPS,
    move_duration: float = MOVE_DURATION,
    theme: str = DEFAULT_THEME,
    white_name: str = "White",
    black_name: str = "Black",
    white_photo: Optional[str] = None,
    black_photo: Optional[str] = None,
    white_flag: Optional[str] = None,
    black_flag: Optional[str] = None,
    commentary_lines: Optional[List[str]] = None,
    voice: str = "en-US-ChristopherNeural",
) -> str:
    """
    Board video + move sounds + spoken commentary (Gemini lines or SAN fallback).
    """
    if not HAS_TTS:
        print("⚠️  edge-tts not installed. Falling back to silent video.")
        print("   Install with: pip install edge-tts")
        return create_silent_video(
            analysis, output_path, fps, move_duration, theme,
            white_name, black_name, white_photo, black_photo, white_flag, black_flag,
        )

    frames = []
    durations = []
    audio_clips = []
    current_time = 0.0
    lines = commentary_lines or []

    img = render_frame(
        analysis[0]["fen"], last_move=None,
        best_move=analysis[0].get("best_move"),
        is_check=analysis[0].get("is_check", False),
        theme=theme,
        white_name=white_name, black_name=black_name,
        white_photo=white_photo, black_photo=black_photo,
        white_flag=white_flag, black_flag=black_flag,
    )
    if watermark:
        img = apply_watermark(img.convert("RGB"), watermark)
    else:
        img = img.convert("RGB")
    if elo_badge:
        img = apply_elo_badge(img, elo_badge)
    # Intro card same size as board frames
    if intro_card:
        try:
            intro = make_intro_card(
                white_name, black_name,
                opening=opening_text or "",
                clock_text=clock_text or "",
                size=img.size,
            )
            if watermark:
                intro = apply_watermark(intro, watermark)
            frames.append(np.array(intro.convert("RGB")))
            durations.append(2.2)
            current_time += 2.2
        except Exception as e:
            print(f"Intro card skipped: {e}")
    if viral_hook:
        try:
            hc = make_viral_hook_card(viral_hook, subtitle="Watch till the end", size=img.size)
            if watermark:
                hc = apply_watermark(hc, watermark)
            frames.append(np.array(hc.convert("RGB")))
            durations.append(1.8)
            current_time += 1.8
        except Exception as e:
            print(f"Viral hook skipped: {e}")
    frames.append(np.array(img))
    durations.append(PAUSE_AT_START)
    current_time += PAUSE_AT_START

    for i, pos in enumerate(analysis[1:], 1):
        img = render_frame(
            pos["fen"],
            last_move=pos.get("last_move"),
            best_move=pos.get("best_move"),
            is_check=pos.get("is_check", False),
            theme=theme,
            white_name=white_name, black_name=black_name,
            white_photo=white_photo, black_photo=black_photo,
            white_flag=white_flag, black_flag=black_flag,
        )
        frames.append(np.array(img.convert("RGB")))
        dur = move_duration + (0.8 if i == len(analysis) - 1 else 0)
        durations.append(dur)

        move = pos.get("last_move")
        fen_before = analysis[i - 1]["fen"]
        is_cap = _is_capture(move, fen_before)
        is_chk = pos.get("is_check", False)
        if is_chk and CHECK_SOUND.exists():
            sound_path = CHECK_SOUND
        elif is_cap and CAPTURE_SOUND.exists():
            sound_path = CAPTURE_SOUND
        else:
            sound_path = MOVE_SOUND
        if sound_path.exists():
            try:
                ac = AudioFileClip(str(sound_path))
                ac = ac.with_duration(min(0.35, ac.duration)).with_start(current_time)
                audio_clips.append(ac)
            except Exception:
                pass

        # Spoken line
        if i - 1 < len(lines) and lines[i - 1]:
            speak = lines[i - 1]
        else:
            san = pos.get("san") or ""
            speak = san.replace("x", " takes ").replace("+", " check").replace("#", " checkmate")
        if speak:
            try:
                audio_path = asyncio.run(_generate_tts(speak, voice=voice))
                ac = AudioFileClip(audio_path).with_start(current_time + 0.2)
                # don't overrun move window too badly
                if ac.duration > dur - 0.3:
                    ac = ac.with_duration(max(0.5, dur - 0.3))
                audio_clips.append(ac)
            except Exception as e:
                print(f"TTS failed: {e}")

        current_time += dur

    durations[-1] += PAUSE_AT_END
    video = ImageSequenceClip(frames, durations=durations)
    final_audio = CompositeAudioClip(audio_clips) if audio_clips else None
    if final_audio:
        video = video.with_audio(final_audio)
    video.write_videofile(
        output_path, fps=fps, codec="libx264",
        audio_codec="aac" if final_audio else None, logger=None,
    )
    video.close()
    return output_path




def detect_key_moments(analysis: List[dict]) -> List[dict]:
    """
    Tag brilliant / blunder / check / mate from eval swings (white POV).
    Returns list of {index, type, swing, fen, san}.
    """
    moments = []
    if not analysis:
        return moments
    n = len(analysis)
    # Mate / final check
    if n > 1 and analysis[-1].get("is_check"):
        moments.append({
            "index": n - 1,
            "type": "mate" if "#" in str(analysis[-1].get("san") or "") else "check",
            "swing": 0,
            "fen": analysis[-1]["fen"],
            "san": analysis[-1].get("san"),
        })
    for i in range(1, n):
        prev = analysis[i - 1].get("eval_cp")
        cur = analysis[i].get("eval_cp")
        if prev is None or cur is None:
            continue
        swing = cur - prev  # from side to move perspective roughly
        # large drop for side that just moved ≈ blunder; huge gain ≈ brilliant
        abs_swing = abs(swing)
        kind = None
        if abs_swing >= 300:
            # After move, if eval went heavily against the mover → blunder
            # White just moved on odd plies from start... simpler: big negative for white after white move
            mover_white = (i % 2 == 1)
            if mover_white and swing <= -250:
                kind = "blunder"
            elif (not mover_white) and swing >= 250:
                kind = "blunder"
            elif mover_white and swing >= 250:
                kind = "brilliant"
            elif (not mover_white) and swing <= -250:
                kind = "brilliant"
            elif abs_swing >= 400:
                kind = "brilliant" if abs_swing == swing or swing > 0 else "blunder"
        if analysis[i].get("is_check") and kind is None:
            kind = "check"
        if kind:
            moments.append({
                "index": i,
                "type": kind,
                "swing": swing,
                "fen": analysis[i]["fen"],
                "san": analysis[i].get("san"),
            })
    return moments


def pick_hook_from_analysis(analysis: List[dict]) -> tuple:
    """Pick dramatic FEN + hook from brilliant/blunder/mate detection."""
    start_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    if not analysis:
        return start_fen, "CHESS BATTLE"
    moments = detect_key_moments(analysis)
    priority = ["mate", "brilliant", "blunder", "check"]
    for prio in priority:
        for m in moments:
            if m["type"] == prio:
                hooks = {
                    "mate": "CHECKMATE!",
                    "brilliant": "BRILLIANT!",
                    "blunder": "WHAT A BLUNDER!",
                    "check": "IN CHECK!",
                }
                return m["fen"], hooks[prio]
    # fallback last position
    return analysis[-1]["fen"], "EPIC GAME!"


def pick_hooks_ab(analysis: List[dict], n: int = 3) -> List[tuple]:
    """Up to n (fen, hook) pairs for thumbnail A/B."""
    moments = detect_key_moments(analysis)
    hooks_map = {
        "mate": "CHECKMATE!",
        "brilliant": "BRILLIANT!",
        "blunder": "WHAT A BLUNDER!",
        "check": "IN CHECK!",
    }
    seen = set()
    out = []
    for m in moments:
        h = hooks_map.get(m["type"], "EPIC!")
        key = (m["fen"], h)
        if key in seen:
            continue
        seen.add(key)
        out.append((m["fen"], h))
        if len(out) >= n:
            break
    if not out:
        fen, h = pick_hook_from_analysis(analysis)
        out = [(fen, h)]
    # pad variants
    variants = ["INSANE MOVE!", "NO WAY!", "ENGINE MOVE?!"]
    while len(out) < n and out:
        fen = out[0][0]
        for v in variants:
            if len(out) >= n:
                break
            if (fen, v) not in seen:
                out.append((fen, v))
                seen.add((fen, v))
    return out[:n]






def create_viral_thumbnail(
    analysis: List[dict],
    output_path: str,
    white_name: str = "White",
    black_name: str = "Black",
    white_photo: Optional[str] = None,
    black_photo: Optional[str] = None,
    white_flag: Optional[str] = None,
    black_flag: Optional[str] = None,
    hook: Optional[str] = None,
    theme: str = DEFAULT_THEME,
    format: str = "16:9",
) -> str:
    """
    Viral thumbnail in two formats:
      format="16:9" → 1280x720 (YouTube landscape)
      format="9:16" → 1080x1920 (Shorts / Reels vertical)
    No result score, no platform tag. Names rendered larger.
    """
    from PIL import ImageDraw, ImageFont, ImageFilter, ImageOps

    fmt = (format or "16:9").strip().lower().replace("x", ":")
    if fmt in ("9:16", "916", "vertical", "shorts", "portrait"):
        W, H = 1080, 1920
        vertical = True
    else:
        W, H = 1280, 720
        vertical = False

    fen, auto_hook = pick_hook_from_analysis(analysis)
    hook = (hook or auto_hook or "BRILLIANT!").upper()

    def short(n):
        n = (n or "").strip()
        parts = n.split()
        if len(parts) >= 2:
            # Prefer last name but keep readable length
            last = parts[-1]
            return last if len(last) >= 3 else parts[0]
        return n[:16]

    w_short, b_short = short(white_name), short(black_name)
    sub = f"{w_short}  VS  {b_short}"

    img = Image.new("RGB", (W, H), (12, 12, 18))
    draw = ImageDraw.Draw(img)

    # Side gradients
    side = 220 if not vertical else 80
    for x in range(0, side):
        c = int(18 + x * 0.05)
        draw.line([(x, 0), (x, H)], fill=(c, 8, 20))
    for x in range(W - side, W):
        c = int(18 + (W - x) * 0.05)
        draw.line([(x, 0), (x, H)], fill=(8, 12, c))

    bar = 10 if not vertical else 14
    draw.rectangle([0, 0, W, bar], fill=(220, 30, 40))
    draw.rectangle([0, H - bar, W, H], fill=(220, 30, 40))

    # Board size
    board_px = 500 if not vertical else 900
    colors = BOARD_THEMES.get(theme, BOARD_THEMES[DEFAULT_THEME])
    board = chess.Board(fen)
    last_move = None
    for pos in reversed(analysis):
        if pos.get("fen") == fen and pos.get("last_move"):
            last_move = pos["last_move"]
            break
    svg = chess.svg.board(
        board=board, lastmove=last_move, size=board_px + 40,
        coordinates=False, colors=colors,
    )
    png_bytes = cairosvg.svg2png(bytestring=svg.encode("utf-8"))
    board_img = Image.open(io.BytesIO(png_bytes)).convert("RGBA").resize(
        (board_px, board_px), Image.LANCZOS
    )
    bw = bh = board_px
    shadow = Image.new("RGBA", (bw + 24, bh + 24), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rectangle([12, 12, bw + 12, bh + 12], fill=(0, 0, 0, 170))
    shadow = shadow.filter(ImageFilter.GaussianBlur(14))

    if vertical:
        board_y = H // 2 - bh // 2 + 40
    else:
        board_y = H // 2 - bh // 2 + 28
    board_x = W // 2 - bw // 2
    img.paste(shadow, (board_x - 6, board_y - 6), shadow)
    img.paste(board_img, (board_x, board_y), board_img)

    def font(size):
        for fp in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
            "C:/Windows/Fonts/ARIALBD.TTF",
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        ):
            if Path(fp).exists():
                return ImageFont.truetype(fp, size)
        return ImageFont.load_default()

    # Bigger fonts — especially names
    if vertical:
        f_hook, f_sub, f_name = font(92), font(40), font(44)
        photo_size = 160
    else:
        f_hook, f_sub, f_name = font(72), font(32), font(36)
        photo_size = 130

    # Hook
    bbox = draw.textbbox((0, 0), hook, font=f_hook)
    tx = (W - (bbox[2] - bbox[0])) // 2
    ty = 36 if not vertical else 60
    for ox, oy in [(-4, 0), (4, 0), (0, -4), (0, 4), (-3, -3), (3, 3)]:
        draw.text((tx + ox, ty + oy), hook, font=f_hook, fill=(0, 0, 0))
    draw.text((tx, ty), hook, font=f_hook, fill=(255, 45, 45))

    # Subline (names matchup)
    bbox = draw.textbbox((0, 0), sub, font=f_sub)
    draw.text(
        ((W - (bbox[2] - bbox[0])) // 2, ty + (bbox[3] - bbox[1]) + 18),
        sub, font=f_sub, fill=(255, 220, 70),
    )

    def round_photo(path, size=130):
        if not path or not Path(path).exists():
            return None
        try:
            im = Image.open(path).convert("RGBA")
            im = ImageOps.fit(im, (size, size), centering=(0.5, 0.5))
            mask = Image.new("L", (size, size), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, size, size), fill=255)
            out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
            out.paste(im, (0, 0))
            out.putalpha(mask)
            ring = Image.new("RGBA", (size + 10, size + 10), (0, 0, 0, 0))
            ImageDraw.Draw(ring).ellipse(
                (0, 0, size + 9, size + 9), outline=(255, 215, 0), width=5
            )
            ring.paste(out, (5, 5), out)
            return ring
        except Exception:
            return None

    def load_flag(path, h=36):
        if not path or not Path(path).exists():
            return None
        try:
            im = Image.open(path).convert("RGBA")
            w = max(1, int(im.width * h / im.height))
            return im.resize((w, h), Image.LANCZOS)
        except Exception:
            return None

    def draw_player(name, photo_path, flag_path, left: bool):
        photo = round_photo(photo_path, photo_size)
        flag = load_flag(flag_path, 36 if not vertical else 42)
        if vertical:
            # Photos above board, left/right
            py = board_y - photo_size - 70
            if left:
                px = 60
            else:
                px = W - 60 - (photo_size + 10)
        else:
            py = H // 2 - photo_size // 2 - 10
            if left:
                px = 36
            else:
                px = W - 36 - (photo_size + 10)

        if photo:
            img.paste(photo, (px, py), photo)

        # Name under photo — LARGE
        name_y = py + photo_size + 18
        text_x = px
        if flag:
            img.paste(flag, (text_x, name_y + 4), flag)
            text_x += flag.width + 10
        # stroke for readability
        for ox, oy in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
            draw.text((text_x + ox, name_y + oy), name, font=f_name, fill=(0, 0, 0))
        draw.text((text_x, name_y), name, font=f_name, fill=(255, 255, 255))

    draw_player(w_short, white_photo, white_flag, left=True)
    draw_player(b_short, black_photo, black_flag, left=False)

    out = Path(output_path)
    img.save(out, quality=93)
    return str(out)


def create_viral_thumbnails_both(
    analysis: List[dict],
    base_output: str,
    ab_variants: int = 1,
    **kwargs,
) -> list:
    """Write 16:9 and 9:16 thumbnails; optional A/B hook variants."""
    base = Path(base_output)
    stem = base.with_suffix("")
    paths = []
    variants = pick_hooks_ab(analysis, n=max(1, ab_variants))
    for vi, (fen, hook) in enumerate(variants):
        # temporarily bias pick by injecting hook via kwargs
        suffix_prefix = "" if vi == 0 else f"_ab{vi+1}"
        for fmt, suffix in (("16:9", f"{suffix_prefix}_16x9.jpg"), ("9:16", f"{suffix_prefix}_9x16.jpg")):
            out = Path(str(stem) + suffix)
            create_viral_thumbnail(
                analysis, str(out), format=fmt, hook=hook, **kwargs
            )
            paths.append(str(out))
    return paths





# ---------- Gemini (commentary + SEO metadata) ----------
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash-lite").strip()


def _gemini_generate(prompt: str, system: str = "") -> str:
    """Call Gemini generateContent REST API. Needs GEMINI_API_KEY."""
    import urllib.request
    if not GEMINI_API_KEY:
        raise RuntimeError(
            "GEMINI_API_KEY not set. Get a key from https://aistudio.google.com/apikey"
        )
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
    )
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.8,
            "maxOutputTokens": 4096,
        },
    }
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=90) as r:
        resp = json.loads(r.read().decode())
    candidates = resp.get("candidates") or []
    if not candidates:
        raise RuntimeError(f"Gemini empty response: {resp}")
    parts = (candidates[0].get("content") or {}).get("parts") or []
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        raise RuntimeError(f"Gemini no text: {resp}")
    return text


def build_move_list_for_prompt(analysis: List[dict], max_moves: int = 80) -> str:
    lines = []
    for i, pos in enumerate(analysis[1:max_moves + 1], 1):
        san = pos.get("san") or "?"
        chk = " +" if pos.get("is_check") else ""
        lines.append(f"{i}. {san}{chk}")
    return "\n".join(lines)


def generate_commentary_lines_gemini(
    analysis: List[dict],
    white_name: str,
    black_name: str,
    lang: str = "en",
    format: str = "long",
) -> List[str]:
    """
    Energetic commentary lines for TTS.
    format="long"   → move-by-move, total ~1200–1700 words
    format="shorts" → only key moments, total ~120–200 words
    Returns list length == number of moves (empty string = no speech that move).
    """
    moves = build_move_list_for_prompt(analysis)
    n = len(analysis) - 1
    fmt = (format or "long").lower()
    if fmt in ("short", "shorts", "reel", "vertical"):
        fmt = "shorts"
        word_min, word_max = 120, 200
        style = (
            "SHORTS mode: total commentary across the WHOLE game must be "
            f"between {word_min} and {word_max} English words (or equivalent Hindi). "
            "Only comment on critical moments (checks, captures, sacrifices, blunders, mate). "
            "For quiet developing moves use empty string "". "
            "Keep energy high, no result spoilers early."
        )
    else:
        fmt = "long"
        word_min, word_max = 1200, 1700
        style = (
            "LONG VIDEO mode: move-by-move commentary. "
            f"Total words across ALL lines must be about {word_min}–{word_max}. "
            "Every move gets a real line (no empty strings). "
            "Vary length: quiet moves 8–15 words, critical moments 20–40 words. "
            "Energetic American YouTuber tone, teach + hype, no early result spoilers."
        )

    if lang == "hi":
        system = (
            "You are an energetic Hindi chess commentator for YouTube. "
            "Reply ONLY with a JSON array of strings with exactly one entry per move. "
            "Mix Hindi + chess terms. No markdown, no numbering outside JSON."
        )
        lang_note = "Write lines in Hindi (chess terms can stay English)."
    else:
        system = (
            "You are an energetic American-accent chess YouTuber commentator. "
            "Reply ONLY with a JSON array of strings with exactly one entry per move. "
            "No markdown, no numbering outside JSON."
        )
        lang_note = "Write lines in English."

    prompt = (
        f"Players: {white_name} (White) vs {black_name} (Black).\n"
        f"Mode: {fmt.upper()}\n"
        f"{style}\n"
        f"{lang_note}\n"
        f"Moves ({n}):\n{moves}\n\n"
        f"Return a JSON array with exactly {n} strings (index 0 = first move)."
    )
    raw = _gemini_generate(prompt, system=system)
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        arr = json.loads(raw)
    except Exception:
        arr = [ln.strip("- •\t ") for ln in raw.splitlines() if ln.strip()]
    if not isinstance(arr, list):
        arr = [str(arr)]
    # keep empties for shorts; only strip whitespace
    arr = [str(x).strip() if x is not None else "" for x in arr]
    if fmt == "long":
        while len(arr) < n:
            idx = len(arr) + 1
            san = analysis[idx].get("san") if idx < len(analysis) else "move"
            arr.append(str(san))
    else:
        while len(arr) < n:
            arr.append("")
    arr = arr[:n]
    total_words = sum(len(x.split()) for x in arr if x)
    print(f"   Commentary format={fmt} lines={n} words≈{total_words} (target {word_min}-{word_max})")
    return arr


def generate_youtube_metadata_gemini(
    game: chess.pgn.Game,
    analysis: List[dict],
    white_name: str,
    black_name: str,
    platform_hint: str = "",
) -> dict:
    """Gemini: viral hook, titles EN+HI, description, hashtags, SEO tags — one shot."""
    headers = game.headers
    result = headers.get("Result", "*")
    event = headers.get("Event", "") or ""
    eco = headers.get("ECO", "") or ""
    moves = build_move_list_for_prompt(analysis, max_moves=40)
    n = max(0, len(analysis) - 1)
    system = (
        "You are a viral chess YouTube SEO expert for Indian + global audience. "
        "Return ONLY valid JSON, no markdown."
    )
    prompt = f"""
Game info:
- White: {white_name}
- Black: {black_name}
- Result: {result}
- Event: {event}
- ECO: {eco}
- Moves ({n}): 
{moves}
- Platform hint: {platform_hint or "chess"}

Return JSON with keys:
{{
  "hook": "short English hook e.g. BRILLIANT SAC",
  "hook_hi": "Hindi hook",
  "title": "English YouTube title under 90 chars, no result score",
  "title_hi": "Hindi title under 90 chars",
  "shorts_title": "English shorts title under 50 chars",
  "shorts_title_hi": "Hindi shorts title under 50 chars",
  "title_options": ["en option1", "en option2", "en option3"],
  "title_options_hi": ["hi option1", "hi option2", "hi option3"],
  "description": "English description 400-800 chars with CTA",
  "description_hi": "Hindi description 400-800 chars with CTA",
  "hashtags": ["#chess", "#checkmate", "... up to 20"],
  "tags": ["chess", "chessshorts", "... up to 25 without #"]
}}
Make titles clickbait but not fake. Do NOT put 1-0 or 0-1 in titles.
"""
    raw = _gemini_generate(prompt, system=system)
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    data = json.loads(raw)
    # normalize
    meta = {
        "title": data.get("title") or f"{white_name} vs {black_name}",
        "title_hi": data.get("title_hi") or data.get("title", ""),
        "shorts_title": data.get("shorts_title") or data.get("title", "")[:50],
        "shorts_title_hi": data.get("shorts_title_hi") or "",
        "title_options": data.get("title_options") or [],
        "title_options_hi": data.get("title_options_hi") or [],
        "description": data.get("description") or "",
        "description_hi": data.get("description_hi") or "",
        "hashtags": data.get("hashtags") or [],
        "tags": data.get("tags") or [],
        "hook": data.get("hook") or "BRILLIANT",
        "hook_hi": data.get("hook_hi") or "",
        "opening": eco,
        "result": result,
        "moves": n,
        "white": white_name,
        "black": black_name,
        "source": "gemini",
    }
    # ensure hashtag #
    meta["hashtags"] = [
        h if str(h).startswith("#") else f"#{h}" for h in meta["hashtags"]
    ]
    return meta



def generate_youtube_metadata(
    game: chess.pgn.Game,
    analysis: List[dict],
    white_name: str,
    black_name: str,
    hook: Optional[str] = None,
    platform_hint: str = "",
) -> dict:
    """
    Auto title, description, hashtags — English + Hindi viral options.
    """
    headers = game.headers
    result = headers.get("Result", "*")
    event = headers.get("Event", "") or ""
    eco = headers.get("ECO", "") or ""
    date = headers.get("Date", "") or ""
    site = headers.get("Site", "") or ""

    fen, auto_hook = pick_hook_from_analysis(analysis)
    hook = (hook or auto_hook or "INSANE GAME").upper().replace("!", "").strip()

    ECO_NAMES = {
        "C41": "Philidor Defense",
        "C20": "King's Pawn",
        "B20": "Sicilian Defense",
        "D00": "Queen's Pawn",
        "E00": "Catalan / Indian",
        "C00": "French Defense",
        "C60": "Ruy Lopez",
        "B90": "Najdorf Sicilian",
        "D37": "QGD",
        "A00": "Uncommon Opening",
    }
    ECO_HI = {
        "C41": "Philidor Defense",
        "B20": "Sicilian Defense",
        "C60": "Ruy Lopez",
        "C00": "French Defense",
    }
    opening = ECO_NAMES.get(eco[:3], "") if eco else ""
    if eco and not opening:
        opening = f"ECO {eco}"

    n_moves = max(0, len(analysis) - 1)
    winner = white_name if result == "1-0" else (black_name if result == "0-1" else None)
    w_last = white_name.split()[-1] if white_name else "White"
    b_last = black_name.split()[-1] if black_name else "Black"

    # Hindi hook mapping
    HOOK_HI = {
        "CHECKMATE": "शाहमात",
        "CHECKMATE!": "शाहमात",
        "BRILLIANT": "जबरदस्त चाल",
        "BRILLIANT!": "जबरदस्त चाल",
        "IN CHECK": "शाह",
        "BLUNDER": "बड़ी गलती",
        "INSANE GAME": "धमाकेदार गेम",
    }
    hook_hi = HOOK_HI.get(hook, HOOK_HI.get(hook.replace("!", ""), "धमाकेदार गेम"))

    # ---- English titles ----
    titles_en = []
    if "CHECKMATE" in hook:
        titles_en += [
            f"{white_name} vs {black_name} | {hook} in {n_moves} Moves",
            f"{hook}! {winner or white_name} Crushes the Game",
            f"1 Move From Glory | {w_last} vs {b_last}",
        ]
    elif "BLUNDER" in hook:
        titles_en += [
            f"{hook}! {white_name} vs {black_name}",
            f"This Blunder Ended Everything | {w_last} vs {b_last}",
        ]
    elif "BRILLIANT" in hook:
        titles_en += [
            f"{hook} Sacrifice | {white_name} vs {black_name}",
            f"Engine-Level Move | {w_last} vs {b_last}",
        ]
    else:
        titles_en += [
            f"{white_name} vs {black_name} | {hook}",
            f"{hook} | {w_last} vs {b_last} Chess",
        ]
    if opening:
        titles_en.append(f"{opening} | {white_name} vs {black_name}")
    titles_en.append(f"{white_name} vs {black_name} | Chess Highlights")

    title_en = titles_en[0][:100]
    shorts_en = f"{hook} | {w_last} vs {b_last}"

    # ---- Hindi titles ----
    titles_hi = []
    if "CHECKMATE" in hook:
        titles_hi += [
            f"{white_name} vs {black_name} | {n_moves} चाल में {hook_hi}",
            f"{hook_hi}! {winner or white_name} ने गेम खत्म कर दिया",
            f"{w_last} vs {b_last} | ऐसा {hook_hi} पहले नहीं देखा",
        ]
    elif "BLUNDER" in hook:
        titles_hi += [
            f"{hook_hi}! {white_name} vs {black_name}",
            f"एक गलती और गेम खत्म | {w_last} vs {b_last}",
        ]
    elif "BRILLIANT" in hook:
        titles_hi += [
            f"{hook_hi} | {white_name} vs {black_name}",
            f"कंप्यूटर जैसी चाल | {w_last} vs {b_last}",
        ]
    else:
        titles_hi += [
            f"{white_name} vs {black_name} | {hook_hi}",
            f"{hook_hi} | {w_last} vs {b_last} शतरंज",
        ]
    if opening:
        titles_hi.append(f"{opening} | {white_name} vs {black_name}")
    titles_hi.append(f"{white_name} vs {black_name} | शतरंज हाइलाइट्स")

    title_hi = titles_hi[0][:100]
    shorts_hi = f"{hook_hi} | {w_last} vs {b_last}"

    # ---- Descriptions EN + HI ----
    desc_en = [
        f"♟️ {white_name} vs {black_name}",
        f"Hook moment: {hook}",
        "",
    ]
    desc_hi = [
        f"♟️ {white_name} vs {black_name}",
        f"खास पल: {hook_hi}",
        "",
    ]
    for label_en, label_hi, val in (
        ("Event", "इवेंट", event),
        ("Site", "स्थल", site),
        ("Date", "तारीख", date),
    ):
        if val and val not in ("?", "-") and not str(val).startswith("?"):
            desc_en.append(f"{label_en}: {val}")
            desc_hi.append(f"{label_hi}: {val}")
    if opening:
        desc_en.append(f"Opening: {opening}" + (f" ({eco})" if eco else ""))
        desc_hi.append(f"ओपनिंग: {opening}" + (f" ({eco})" if eco else ""))
    elif eco:
        desc_en.append(f"ECO: {eco}")
        desc_hi.append(f"ECO: {eco}")
    desc_en.append(f"Moves shown: {n_moves}")
    desc_hi.append(f"चालें: {n_moves}")
    if result and result != "*":
        extra = f" — Winner: {winner}" if winner else ""
        extra_hi = f" — विजेता: {winner}" if winner else ""
        desc_en.append(f"Result: {result}{extra}")
        desc_hi.append(f"परिणाम: {result}{extra_hi}")
    if platform_hint:
        desc_en.append(f"Source: {platform_hint}")
        desc_hi.append(f"स्रोत: {platform_hint}")

    desc_en += [
        "",
        "Watch the key ideas, tactics, and the decisive moment.",
        "Silent board + arrows style for clean study / shorts.",
        "",
        "👍 Like | 💬 Comment | 🔔 Subscribe for daily chess",
    ]
    desc_hi += [
        "",
        "जरूरी आइडिया, टैक्टिक्स और फैसलाकुन पल देखें।",
        "साइलेंट बोर्ड + एरो स्टाइल — पढ़ाई और शॉर्ट्स के लिए।",
        "",
        "👍 लाइक | 💬 कमेंट | 🔔 रोज़ाना शतरंज के लिए सब्सक्राइब",
    ]

    # ---- Hashtags (EN + some Hindi roman) ----
    tags_core = [
        "chess", "chessgame", "chessmaster", "grandmaster",
        "chessmoves", "chessplay", "chessshorts", "chessvideo",
        "stockfish", "tactics", "checkmate", "chesshighlights",
        "shatranj", "shatranjgame", "chesshindi",
    ]
    name_tags = []
    for n in (white_name, black_name):
        clean = "".join(ch for ch in n if ch.isalnum() or ch.isspace()).strip()
        if clean:
            name_tags.append(clean.replace(" ", "").lower())
    seen = set()
    hashtags = []
    extra = ["chessopening", opening.replace(" ", "").lower()] if opening else []
    for h in name_tags + tags_core + extra:
        h = h.strip().lstrip("#")
        if not h or h.lower() in seen:
            continue
        seen.add(h.lower())
        hashtags.append(f"#{h}")

    description_en = "\n".join(desc_en) + "\n\n---\nHashtags:\n" + " ".join(hashtags[:25])
    description_hi = "\n".join(desc_hi) + "\n\n---\nहैशटैग:\n" + " ".join(hashtags[:25])

    return {
        "title": title_en,
        "title_hi": title_hi,
        "shorts_title": shorts_en,
        "shorts_title_hi": shorts_hi,
        "title_options": titles_en[:6],
        "title_options_hi": titles_hi[:6],
        "description": description_en,
        "description_hi": description_hi,
        "hashtags": hashtags[:25],
        "tags": [h.lstrip("#") for h in hashtags[:30]],
        "hook": hook,
        "hook_hi": hook_hi,
        "opening": opening,
        "result": result,
        "moves": n_moves,
        "white": white_name,
        "black": black_name,
    }



def save_youtube_metadata(meta: dict, output_path: str) -> str:
    """Save human-readable .txt + machine .json next to video."""
    base = Path(output_path).with_suffix("")
    txt_path = Path(str(base) + "_youtube.txt")
    json_path = Path(str(base) + "_youtube.json")

    txt = []
    txt.append("=" * 50)
    txt.append("YOUTUBE / SHORTS METADATA (EN + HI)")
    txt.append("=" * 50)
    txt.append("")
    txt.append("--- ENGLISH ---")
    txt.append("TITLE:")
    txt.append(meta.get("title", ""))
    txt.append("")
    txt.append("SHORTS TITLE:")
    txt.append(meta.get("shorts_title", ""))
    txt.append("")
    txt.append("TITLE OPTIONS:")
    for i, t in enumerate(meta.get("title_options") or [], 1):
        txt.append(f"  {i}. {t}")
    txt.append("")
    txt.append("DESCRIPTION:")
    txt.append(meta.get("description", ""))
    txt.append("")
    txt.append("--- HINDI / हिन्दी ---")
    txt.append("टाइटल:")
    txt.append(meta.get("title_hi", ""))
    txt.append("")
    txt.append("शॉर्ट्स टाइटल:")
    txt.append(meta.get("shorts_title_hi", ""))
    txt.append("")
    txt.append("टाइटल विकल्प:")
    for i, t in enumerate(meta.get("title_options_hi") or [], 1):
        txt.append(f"  {i}. {t}")
    txt.append("")
    txt.append("डिस्क्रिप्शन:")
    txt.append(meta.get("description_hi", ""))
    txt.append("")
    txt.append("--- TAGS / HASHTAGS ---")
    txt.append("TAGS (YouTube tags field):")
    txt.append(", ".join(meta.get("tags") or []))
    txt.append("")
    txt.append("HASHTAGS:")
    txt.append(" ".join(meta.get("hashtags") or []))
    txt.append("")

    txt_path.write_text("\n".join(txt), encoding="utf-8")
    json_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    return str(txt_path)




def export_reels_vertical(
    analysis: List[dict],
    output_path: str,
    move_duration: float = 2.0,
    theme: str = DEFAULT_THEME,
    white_name: str = "White",
    black_name: str = "Black",
    white_photo: Optional[str] = None,
    black_photo: Optional[str] = None,
    white_flag: Optional[str] = None,
    black_flag: Optional[str] = None,
    clock_text: Optional[str] = None,
    voice: bool = False,
    hook_line: str = "",
    max_seconds: float = 40.0,
) -> str:
    """
    9:16 Reels/TikTok style export from climax window.
    Renders board frames centered on a 1080x1920 canvas.
    """
    from PIL import Image as PILImage
    start, end = find_climax_window(analysis, window_moves=12)
    sub = analysis[start:end] if end - start >= 2 else analysis
    W, H = 1080, 1920
    frames, durations, audio_clips = [], [], []
    tcur = 0.0
    key_indices = {m["index"] - start for m in detect_key_moments(analysis) if start <= m["index"] < end}

    # Shorts hype voice (start)
    if voice and HAS_TTS:
        line = hook_line or "Watch this trap!"
        try:
            path = asyncio.run(_generate_tts(line, voice="en-US-ChristopherNeural"))
            ac = AudioFileClip(path).with_start(0.05)
            if ac.duration > 2.5:
                ac = ac.with_duration(2.5)
            audio_clips.append(ac)
        except Exception as e:
            print(f"Shorts voice failed: {e}")

    def frame_to_vertical(img: PILImage.Image) -> PILImage.Image:
        canvas = PILImage.new("RGB", (W, H), (12, 12, 18))
        # scale board to fit width with margin
        max_w = int(W * 0.92)
        ratio = max_w / img.width
        nh = int(img.height * ratio)
        im = img.resize((max_w, nh), PILImage.LANCZOS)
        x = (W - max_w) // 2
        y = (H - nh) // 2
        canvas.paste(im.convert("RGB"), (x, y))
        return canvas

    for i, pos in enumerate(sub):
        img = render_frame(
            pos["fen"],
            last_move=pos.get("last_move"),
            best_move=pos.get("best_move"),
            is_check=pos.get("is_check", False),
            theme=theme,
            white_name=white_name, black_name=black_name,
            white_photo=white_photo, black_photo=black_photo,
            white_flag=white_flag, black_flag=black_flag,
            eval_cp=pos.get("eval_cp"),
            show_eval_bar=True,
            clock_text=clock_text,
        )
        if i in key_indices:
            # mild zoom already optional; vertical paste handles framing
            pass
        vert = frame_to_vertical(img)
        cap = pos.get("san") or ""
        if pos.get("is_check") and i == len(sub) - 1:
            cap = "CHECKMATE!"
        if cap:
            vert = burn_caption(vert, cap)
        frames.append(np.array(vert))
        if voice and HAS_TTS and i == len(sub) - 1:
            try:
                path = asyncio.run(_generate_tts("Checkmate!", voice="en-US-ChristopherNeural"))
                ac = AudioFileClip(path).with_start(tcur + 0.1)
                if ac.duration > 1.5:
                    ac = ac.with_duration(1.5)
                audio_clips.append(ac)
            except Exception:
                pass
        dur = move_duration + (0.5 if i == len(sub) - 1 else 0)
        durations.append(dur)
        if i > 0 and MOVE_SOUND.exists():
            try:
                ac = AudioFileClip(str(MOVE_SOUND))
                ac = ac.with_duration(min(0.18, ac.duration)).with_start(tcur)
                audio_clips.append(ac)
            except Exception:
                pass
        tcur += dur

    total = sum(durations)
    if max_seconds and total > max_seconds > 0:
        scale = max_seconds / total
        durations = [max(0.35, d * scale) for d in durations]
        print(f"   Shorts capped to ~{max_seconds:.0f}s (was {total:.1f}s)")

    clip = ImageSequenceClip(frames, durations=durations)
    if audio_clips:
        clip = clip.with_audio(CompositeAudioClip(audio_clips))
    clip.write_videofile(output_path, fps=FPS, codec="libx264", audio_codec="aac", logger=None)
    clip.close()
    return output_path



def post_discord_log(webhook_url: str, title: str, url: str = "", extra: str = "") -> bool:
    """POST a simple embed-like message to Discord webhook."""
    import urllib.request
    if not webhook_url:
        return False
    content = f"**{title}**\n{url}\n{extra}".strip()
    data = json.dumps({"content": content[:1900]}).encode("utf-8")
    req = urllib.request.Request(
        webhook_url, data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return 200 <= r.status < 300
    except Exception as e:
        print(f"Discord log failed: {e}")
        return False


def append_drive_log(log_path: str, row: dict) -> None:
    """Append JSONL log row (for Drive sync / sheets import)."""
    path = Path(log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")





def make_viral_hook_card(
    hook: str,
    subtitle: str = "",
    size: tuple = (720, 848),
) -> "Image.Image":
    """Fullscreen 1-2s hook for Shorts retention."""
    from PIL import ImageDraw, ImageFont
    W, H = size
    img = Image.new("RGB", (W, H), (8, 8, 12))
    draw = ImageDraw.Draw(img)

    def font(sz):
        for fp in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ):
            if Path(fp).exists():
                return ImageFont.truetype(fp, sz)
        return ImageFont.load_default()

    # Split long hooks into 2 lines
    hook = (hook or "CHESS TRAP").upper()
    words = hook.split()
    if len(hook) > 18 and len(words) > 1:
        mid = len(words) // 2
        lines_txt = [" ".join(words[:mid]), " ".join(words[mid:])]
    else:
        lines_txt = [hook]

    fbig = font(52 if len(hook) < 16 else 40)
    total_h = 0
    sizes = []
    for line in lines_txt:
        bb = draw.textbbox((0, 0), line, font=fbig)
        sizes.append((bb[2] - bb[0], bb[3] - bb[1]))
        total_h += sizes[-1][1] + 8
    y = H // 2 - total_h // 2 - 20
    for line, (tw, th) in zip(lines_txt, sizes):
        draw.text(((W - tw) // 2, y), line, font=fbig, fill=(255, 40, 40))
        y += th + 10
    if subtitle:
        fs = font(22)
        bb = draw.textbbox((0, 0), subtitle, font=fs)
        tw = bb[2] - bb[0]
        draw.text(((W - tw) // 2, y + 20), subtitle, font=fs, fill=(255, 220, 80))
    draw.rectangle([0, 0, W, 12], fill=(220, 30, 40))
    draw.rectangle([0, H - 12, W, H], fill=(220, 30, 40))
    return img


def make_end_screen(
    white_name: str,
    black_name: str,
    size: tuple = (720, 848),
    next_trap: str = "",
) -> "Image.Image":
    """Subscribe card + optional next trap teaser."""
    from PIL import ImageDraw, ImageFont
    W, H = size
    img = Image.new("RGB", (W, H), (18, 18, 24))
    draw = ImageDraw.Draw(img)

    def font(sz):
        for fp in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ):
            if Path(fp).exists():
                return ImageFont.truetype(fp, sz)
        return ImageFont.load_default()

    blocks = [
        ("Thanks for watching!", font(34), (255, 255, 255), H // 2 - 100),
        (f"{white_name}  vs  {black_name}", font(20), (255, 220, 80), H // 2 - 40),
        ("LIKE  •  COMMENT  •  SUBSCRIBE", font(22), (255, 80, 80), H // 2 + 20),
    ]
    if next_trap:
        blocks.append((f"Next: {next_trap}", font(24), (100, 200, 255), H // 2 + 80))
        blocks.append(("Watch the series →", font(18), (160, 160, 170), H // 2 + 120))
    else:
        blocks.append(("More chess daily", font(18), (180, 180, 190), H // 2 + 80))
    for text, f, color, y in blocks:
        bb = draw.textbbox((0, 0), text, font=f)
        tw = bb[2] - bb[0]
        draw.text(((W - tw) // 2, y), text, font=f, fill=color)
    draw.rectangle([0, 0, W, 8], fill=(220, 30, 40))
    draw.rectangle([0, H - 8, W, H], fill=(220, 30, 40))
    return img


def next_trap_suggestion(current_key: str = "") -> str:
    order = [s["key"] for s in scan_trending_suggestions()]
    if not order:
        return ""
    if current_key in order:
        i = order.index(current_key)
        nxt = order[(i + 1) % len(order)]
    else:
        nxt = order[0]
    traps = list_traps()
    return (traps.get(nxt) or {}).get("name") or nxt


def trap_of_the_day() -> str:
    """Rotate trending trap by day of year."""
    import datetime
    order = [s["key"] for s in scan_trending_suggestions()]
    if not order:
        return "stafford"
    day = datetime.datetime.utcnow().timetuple().tm_yday
    return order[day % len(order)]



def make_intro_card(
    white_name: str,
    black_name: str,
    opening: str = "",
    clock_text: str = "",
    size: tuple = (720, 848),
) -> "Image.Image":
    """Opening title card before moves."""
    from PIL import ImageDraw, ImageFont
    W, H = size
    img = Image.new("RGB", (W, H), (14, 14, 20))
    draw = ImageDraw.Draw(img)

    def font(sz):
        for fp in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ):
            if Path(fp).exists():
                return ImageFont.truetype(fp, sz)
        return ImageFont.load_default()

    lines = [
        ("CHESS HIGHLIGHTS", font(28), (255, 60, 60), H // 2 - 120),
        (f"{white_name}", font(32), (255, 255, 255), H // 2 - 50),
        ("vs", font(22), (180, 180, 190), H // 2),
        (f"{black_name}", font(32), (255, 255, 255), H // 2 + 40),
    ]
    if opening:
        lines.append((opening[:40], font(18), (255, 220, 80), H // 2 + 100))
    if clock_text:
        lines.append((str(clock_text), font(16), (160, 160, 170), H // 2 + 140))
    for text, f, color, y in lines:
        bb = draw.textbbox((0, 0), text, font=f)
        tw = bb[2] - bb[0]
        draw.text(((W - tw) // 2, y), text, font=f, fill=color)
    draw.rectangle([0, 0, W, 8], fill=(220, 30, 40))
    draw.rectangle([0, H - 8, W, H], fill=(220, 30, 40))
    return img


def apply_watermark(img: "Image.Image", text: str = "@YourChannel") -> "Image.Image":
    """Semi-transparent channel watermark top-right."""
    from PIL import ImageDraw, ImageFont, Image as PILImage
    if not text:
        return img
    base = img.convert("RGBA")
    overlay = PILImage.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
    except Exception:
        f = ImageFont.load_default()
    bb = draw.textbbox((0, 0), text, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    x, y = base.width - tw - 14, 12
    draw.rounded_rectangle([x - 8, y - 4, x + tw + 8, y + th + 4], radius=5, fill=(0, 0, 0, 110))
    draw.text((x, y), text, font=f, fill=(255, 255, 255, 160))
    return PILImage.alpha_composite(base, overlay).convert("RGB")


def burn_caption(img: "Image.Image", text: str) -> "Image.Image":
    """Bottom caption bar for Shorts/Reels."""
    from PIL import ImageDraw, ImageFont
    if not text:
        return img
    im = img.convert("RGB")
    draw = ImageDraw.Draw(im)
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
    except Exception:
        f = ImageFont.load_default()
    label = text[:48]
    bb = draw.textbbox((0, 0), label, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    W, H = im.size
    pad = 10
    y = H - th - 28
    draw.rounded_rectangle(
        [(W - tw) // 2 - pad, y - 6, (W + tw) // 2 + pad, y + th + 8],
        radius=8, fill=(0, 0, 0),
    )
    draw.text(((W - tw) // 2, y), label, font=f, fill=(255, 255, 255))
    return im


def compress_video_for_telegram(src: str, dst: str = None, target_mb: float = 45.0) -> str:
    """Re-encode smaller for Telegram bot limit (~50MB)."""
    import subprocess
    src_p = Path(src)
    out = Path(dst) if dst else src_p.with_name(src_p.stem + "_tg.mp4")
    size_mb = src_p.stat().st_size / (1024 * 1024)
    if size_mb <= target_mb:
        return str(src_p)
    # rough CRF bump
    cmd = [
        "ffmpeg", "-y", "-i", str(src_p),
        "-c:v", "libx264", "-preset", "fast", "-crf", "28",
        "-c:a", "aac", "-b:a", "96k",
        "-movflags", "+faststart",
        str(out),
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        return str(out)
    except Exception as e:
        print(f"compress failed: {e}")
        return str(src_p)


def load_agent_config() -> dict:
    cfg_path = SCRIPT_DIR / "chess_agent_config.json"
    defaults = {
        "clock": "10+0",
        "watermark": "",
        "theme": "green",
        "duration": 7,
        "bg_music": False,
        "discord_webhook": "",
        "youtube_privacy": "private",
        "youtube_playlist_id": "",
    }
    if cfg_path.exists():
        try:
            data = json.loads(cfg_path.read_text(encoding="utf-8"))
            defaults.update({k: v for k, v in data.items() if v is not None})
        except Exception:
            pass
    return defaults




TRAPS_DIR = SCRIPT_DIR / "traps"


def list_traps() -> dict:
    idx = TRAPS_DIR / "INDEX.json"
    if idx.exists():
        return json.loads(idx.read_text(encoding="utf-8"))
    return {}


def resolve_trap(name: str) -> tuple:
    """Return (pgn_text, meta_dict) for trap key or friendly name."""
    traps = list_traps()
    key = name.strip().lower().replace(" ", "_").replace("-", "_")
    aliases = {
        "legal": "legals_mate", "legals": "legals_mate", "legal_mate": "legals_mate",
        "stafford_gambit": "stafford", "rosen": "stafford",
        "fried": "fried_liver", "friedliver": "fried_liver", "fegatello": "fried_liver",
        "scholar": "scholars_mate", "scholars": "scholars_mate",
        "blackburne": "blackburne_shilling", "shilling": "blackburne_shilling",
        "englund_gambit": "englund",
        "lasker": "lasker_trap", "albin": "lasker_trap",
        "fishing": "fishing_pole", "fishingpole": "fishing_pole",
        "missile": "icbm", "icbm_gambit": "icbm",
        "danish_gambit": "danish",
    }
    key = aliases.get(key, key)
    if key not in traps:
        # fuzzy
        for k in traps:
            if key in k or k in key:
                key = k
                break
    if key not in traps:
        raise FileNotFoundError(
            f"Unknown trap '{name}'. Available: {', '.join(sorted(traps.keys()))}"
        )
    pgn_path = TRAPS_DIR / f"{key}.pgn"
    if not pgn_path.exists():
        raise FileNotFoundError(f"Missing PGN: {pgn_path}")
    meta = dict(traps[key])
    meta["key"] = key
    return pgn_path.read_text(encoding="utf-8"), meta



def load_refutation(trap_key: str) -> Optional[str]:
    path = TRAPS_DIR / "refutations" / f"{trap_key}.pgn"
    if path.exists():
        return path.read_text(encoding="utf-8")
    return None


def make_section_card(title: str, subtitle: str = "", size: tuple = (720, 848)) -> "Image.Image":
    from PIL import ImageDraw, ImageFont
    W, H = size
    img = Image.new("RGB", (W, H), (12, 12, 18))
    draw = ImageDraw.Draw(img)
    def font(sz):
        for fp in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ):
            if Path(fp).exists():
                return ImageFont.truetype(fp, sz)
        return ImageFont.load_default()
    f = font(36)
    bb = draw.textbbox((0, 0), title, font=f)
    tw = bb[2] - bb[0]
    draw.text(((W - tw) // 2, H // 2 - 40), title, font=f, fill=(255, 80, 80))
    if subtitle:
        fs = font(20)
        bb = draw.textbbox((0, 0), subtitle, font=fs)
        tw = bb[2] - bb[0]
        draw.text(((W - tw) // 2, H // 2 + 20), subtitle, font=fs, fill=(255, 220, 80))
    return img


def append_refutation_segment(
    frames, durations, audio_clips, current_time,
    trap_key: str,
    theme: str,
    move_duration: float,
    watermark: Optional[str],
    size: tuple,
) -> float:
    """Append IF THEY DON'T FALL section. Returns updated current_time."""
    pgn = load_refutation(trap_key)
    if not pgn:
        return current_time
    try:
        game = load_game(pgn)
        analysis = analyze_game(game, depth=6)
    except Exception as e:
        print(f"Refutation load failed: {e}")
        return current_time
    card = make_section_card("IF THEY DON'T FALL…", "Correct defense", size=size)
    if watermark:
        card = apply_watermark(card, watermark)
    frames.append(np.array(card.convert("RGB")))
    durations.append(2.0)
    current_time += 2.0
    for i, pos in enumerate(analysis):
        img = render_frame(
            pos["fen"],
            last_move=pos.get("last_move"),
            best_move=pos.get("best_move"),
            is_check=pos.get("is_check", False),
            theme=theme,
            white_name="White", black_name="Black",
            eval_cp=pos.get("eval_cp"),
            show_eval_bar=True,
            clock_text="DEFENSE",
        )
        img = img.convert("RGB")
        if watermark:
            img = apply_watermark(img, watermark)
        frames.append(np.array(img))
        dur = move_duration * 0.85
        durations.append(dur)
        if i > 0 and MOVE_SOUND.exists():
            try:
                ac = AudioFileClip(str(MOVE_SOUND))
                ac = ac.with_duration(min(0.18, ac.duration)).with_start(current_time)
                audio_clips.append(ac)
            except Exception:
                pass
        current_time += dur
    print(f"   + refutation segment ({len(analysis)-1} moves)")
    return current_time



def trap_hashtags(meta: dict) -> list:
    base = ["chess", "chesstraps", "chessshorts", "chessopening", "checkmate"]
    extra = meta.get("tags") or []
    name = (meta.get("name") or "").replace(" ", "").replace("'", "")
    if name:
        extra = list(extra) + [name]
    return list(dict.fromkeys(base + list(extra)))[:25]


def apply_elo_badge(img: "Image.Image", elo_text: str) -> "Image.Image":
    """Bottom-center ELO range badge (same row as clock)."""
    from PIL import ImageDraw, ImageFont, Image as PILImage
    if not elo_text:
        return img
    base = img.convert("RGBA")
    overlay = PILImage.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16)
    except Exception:
        f = ImageFont.load_default()
    label = f"Works ~{elo_text}"
    bb = draw.textbbox((0, 0), label, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    # bottom center
    x = (base.width - tw) // 2
    y = base.height - th - 16
    draw.rounded_rectangle([x - 10, y - 4, x + tw + 10, y + th + 6], radius=6, fill=(20, 80, 40, 220))
    draw.text((x, y), label, font=f, fill=(220, 255, 220, 255))
    return PILImage.alpha_composite(base, overlay).convert("RGB")


def compile_multi_trap(
    trap_keys: list,
    output_path: str,
    move_duration: float = 2.0,
    theme: str = DEFAULT_THEME,
    watermark: str = "",
) -> str:
    """Concatenate several trap videos into one compilation."""
    from moviepy import concatenate_videoclips, VideoFileClip
    clips = []
    tmp_paths = []
    for key in trap_keys:
        pgn, meta = resolve_trap(key)
        game = load_game(pgn)
        analysis = analyze_game(game, depth=8)
        tmp = SCRIPT_DIR / f"_tmp_trap_{key}.mp4"
        create_silent_video(
            analysis, str(tmp), move_duration=move_duration, theme=theme,
            white_name="White", black_name="Black",
            opening_text=meta.get("name"),
            clock_text="10+0",
            elo_badge=meta.get("elo"),
            watermark=watermark or None,
            intro_card=True,
            show_eval_bar=True,
        )
        clips.append(VideoFileClip(str(tmp)))
        tmp_paths.append(tmp)
    final = concatenate_videoclips(clips, method="compose")
    final.write_videofile(output_path, codec="libx264", audio_codec="aac", logger=None)
    final.close()
    for c in clips:
        c.close()
    for tp in tmp_paths:
        try:
            tp.unlink()
        except Exception:
            pass
    return output_path


def scan_trending_suggestions() -> list:
    """Static + library-based trend suggestions (2026 pack)."""
    traps = list_traps()
    order = [
        "stafford", "legals_mate", "fried_liver", "icbm", "blackburne_shilling",
        "lasker_trap", "englund", "fishing_pole", "danish", "scholars_mate",
    ]
    out = []
    for k in order:
        if k in traps:
            m = traps[k]
            out.append({
                "key": k,
                "name": m.get("name"),
                "elo": m.get("elo"),
                "why": "High Shorts demand 2026",
                "command": f"--trap {k}",
            })
    return out



def main():
    parser = argparse.ArgumentParser(description="Chess Video Agent – silent or commentary")
    parser.add_argument("pgn", nargs="?", help="PGN file path")
    parser.add_argument("--pgn", dest="pgn_text", help="Raw PGN string")
    parser.add_argument("--mode", choices=["silent", "commentary"], default="silent",
                        help="silent = only board+arrows | commentary = + move voice")
    parser.add_argument("--out", "-o", default="chess_output.mp4", help="Output MP4 path")
    parser.add_argument("--depth", type=int, default=DEFAULT_DEPTH, help="Stockfish depth")
    parser.add_argument("--duration", type=float, default=MOVE_DURATION,
                        help="Seconds each move is shown")
    parser.add_argument("--theme", choices=list(BOARD_THEMES.keys()), default=DEFAULT_THEME,
                        help="Board color theme: green (Chess.com), brown, blue, purple")
    parser.add_argument("--player", help="Player name — fetch their latest decisive game")
    parser.add_argument("--latest-decisive", action="store_true",
                        help="With --player: auto-fetch latest decisive (1-0/0-1) game")
    parser.add_argument("--source", default="chesscom",
                        choices=["chesscom", "online", "lichess", "tournament", "fide", "offline"],
                        help="ONLINE: chesscom/online | lichess. OFFLINE: tournament/fide/offline (no mix)")
    parser.add_argument("--thumbnail", action="store_true",
                        help="Also generate viral YouTube thumbnail (no result/score on image)")
    parser.add_argument("--meta", action="store_true",
                        help="Generate YouTube title, description, hashtags, tags")
    parser.add_argument("--gemini", action="store_true",
                        help="Use Gemini for commentary + viral SEO metadata (needs GEMINI_API_KEY)")
    parser.add_argument("--lang", choices=["en", "hi"], default="en",
                        help="Commentary language for Gemini/TTS style")
    parser.add_argument("--format", choices=["long", "shorts"], default="long",
                        help="long≈1200-1700 words move-by-move | shorts≈120-200 words key moments")
    parser.add_argument("--shorts-clip", action="store_true",
                        help="Also export climax Shorts clip (*_shorts.mp4)")
    parser.add_argument("--no-eval-bar", action="store_true", help="Disable eval bar")
    parser.add_argument("--thumb-ab", type=int, default=1, metavar="N",
                        help="Thumbnail A/B variants (1-3 hooks)")
    parser.add_argument("--lang-batch", action="store_true",
                        help="With --meta/--gemini: emphasize EN+HI package (already default for meta)")
    parser.add_argument("--reels", action="store_true", help="Also export 9:16 Reels/TikTok clip")
    parser.add_argument("--bg-music", action="store_true", help="Soft background music bed")
    parser.add_argument("--clock", default="", help="Time control badge text e.g. RAPID 10+0")
    parser.add_argument("--discord-webhook", default="", help="Discord webhook URL for upload log")
    parser.add_argument("--log-file", default="", help="JSONL log path (Drive-friendly)")
    parser.add_argument("--watermark", default="", help="Channel watermark e.g. @Chess64")
    parser.add_argument("--no-intro", action="store_true", help="Skip intro title card")
    parser.add_argument("--compress-tg", action="store_true", help="Compress output for Telegram size limit")
    parser.add_argument("--captions", action="store_true", help="Burn simple captions on reels export")
    parser.add_argument("--trap", default="", help="Built-in trap key e.g. stafford, legals_mate")
    parser.add_argument("--list-traps", action="store_true", help="List trap library and exit")
    parser.add_argument("--multi-trap", default="", help="Comma-separated traps → one compilation")
    parser.add_argument("--trend", action="store_true", help="Print trending trap suggestions")
    parser.add_argument("--trap-of-day", action="store_true", help="Use today's trending trap")
    parser.add_argument("--viral-hook", default="", help="Fullscreen hook text e.g. STAFFORD IN 8 MOVES")
    parser.add_argument("--next-trap", default="", help="End card teaser next trap name")
    parser.add_argument("--no-refutation", action="store_true", help="Skip IF THEY DON'T FALL segment")
    parser.add_argument("--shorts-voice", action="store_true", help="Add short TTS hype on Reels/Shorts")
    parser.add_argument("--max-shorts", type=float, default=40.0, help="Max Shorts/Reels length seconds")
    parser.add_argument("--gemini-model", default=None,
                        help="Override Gemini model id (default env GEMINI_MODEL or gemini-2.5-flash-lite)")
    args = parser.parse_args()

    if getattr(args, "list_traps", False):
        for k, m in list_traps().items():
            print(f"  {k:22} {m.get('name')} | ELO {m.get('elo')} | {m.get('side')}")
        return
    if getattr(args, "trend", False):
        for s in scan_trending_suggestions():
            print(f"  {s['key']:22} {s['name']} (~{s['elo']})  →  {s['command']}")
        return
    if getattr(args, "multi_trap", ""):
        keys = [x.strip() for x in args.multi_trap.split(",") if x.strip()]
        out = args.out or "trap_compilation.mp4"
        print(f"▶ Multi-trap compilation: {keys}")
        compile_multi_trap(keys, out, move_duration=args.duration, theme=args.theme,
                           watermark=args.watermark or "")
        print(f"✅ {out}")
        return

    if args.gemini_model:
        globals()["GEMINI_MODEL"] = args.gemini_model

    source = args.pgn_text or args.pgn
    trap_meta = None
    if getattr(args, "trap_of_day", False) and not getattr(args, "trap", ""):
        args.trap = trap_of_the_day()
        print(f"▶ Trap of the day: {args.trap}")
    if getattr(args, "trap", ""):
        print(f"▶ Loading trap: {args.trap}")
        source, trap_meta = resolve_trap(args.trap)
        print(f"   {trap_meta.get('name')} | ELO {trap_meta.get('elo')} | {trap_meta.get('side')}")
        if not args.out:
            args.out = f"{trap_meta.get('key', 'trap')}.mp4"
    if args.player and args.latest_decisive:
        print(f"▶ Fetching latest decisive game for: {args.player} (source={args.source})")
        pgn_text, meta = fetch_latest_decisive_pgn(args.player, source=args.source)
        source = pgn_text
        print(f"   Found: {meta['white']} vs {meta['black']} → {meta['result']}")
        print(f"   Event: {meta.get('event','')} | {meta.get('time_class','')} | {meta.get('source')}")
        if meta.get("url"):
            print(f"   URL: {meta['url']}")
    if not source:
        parser.error("Provide PGN file, --pgn text, or --player NAME --latest-decisive [--source ...]")

    print(f"▶ Loading game...")
    game = load_game(source)

    white_raw = game.headers.get("White", "White")
    black_raw = game.headers.get("Black", "Black")
    # Convert online usernames → real display names when possible
    platform = "lichess" if (getattr(args, "source", "") or "").lower() == "lichess" else "chesscom"
    white = display_name_for(white_raw, platform=platform)
    black = display_name_for(black_raw, platform=platform)
    print(f"   {white} vs {black}")
    if white != white_raw or black != black_raw:
        print(f"   (online ids: {white_raw} vs {black_raw})")

    print(f"▶ Analyzing with Stockfish (depth {args.depth})...")
    analysis = analyze_game(game, depth=args.depth)
    print(f"   {len(analysis)-1} moves analyzed")

    print(f"▶ Resolving player photos + flags from Chess.com...")
    wp, wf = resolve_player_assets(white)
    bp, bf = resolve_player_assets(black)
    print(f"   White: photo={'yes' if wp else 'no'} flag={'yes' if wf else 'no'}")
    print(f"   Black: photo={'yes' if bp else 'no'} flag={'yes' if bf else 'no'}")

    thumb_paths = []
    if getattr(args, "thumbnail", False):
        base = str(Path(args.out).with_suffix(""))
        print(f"▶ Generating viral thumbnails (16:9 + 9:16)…")
        thumb_paths = create_viral_thumbnails_both(
            analysis, base,
            ab_variants=max(1, min(3, getattr(args, "thumb_ab", 1) or 1)),
            white_name=white, black_name=black,
            white_photo=wp, black_photo=bp, white_flag=wf, black_flag=bf,
            theme=args.theme,
        )
        for tp in thumb_paths:
            print(f"✅ Thumbnail: {tp}")

    # If user only asked for thumbnail path as .jpg, skip video
    if args.out.lower().endswith((".jpg", ".png", ".jpeg")) and getattr(args, "thumbnail", False):
        print(f"✅ Done!")
        return

    meta_path = None
    use_gemini = getattr(args, "gemini", False) or bool(GEMINI_API_KEY and getattr(args, "meta", False))
    if getattr(args, "meta", False) or getattr(args, "thumbnail", False) or getattr(args, "gemini", False):
        platform_hint = getattr(args, "source", "") or ""
        if getattr(args, "gemini", False) or (GEMINI_API_KEY and getattr(args, "meta", False)):
            print(f"▶ Gemini SEO metadata ({GEMINI_MODEL})…")
            try:
                meta = generate_youtube_metadata_gemini(
                    game, analysis, white, black, platform_hint=platform_hint,
                )
            except Exception as e:
                print(f"⚠️ Gemini metadata failed ({e}), using local templates")
                meta = generate_youtube_metadata(
                    game, analysis, white, black, platform_hint=platform_hint,
                )
        else:
            print("▶ Generating YouTube title / description / hashtags (local)…")
            meta = generate_youtube_metadata(
                game, analysis, white, black, platform_hint=platform_hint,
            )
        meta_path = save_youtube_metadata(meta, args.out)
        print(f"✅ Metadata: {meta_path}")
        
        if trap_meta and trap_meta.get("titles"):
            meta["title_options"] = list(trap_meta["titles"])[:5]
            meta["title"] = trap_meta["titles"][0]
            meta["shorts_title"] = trap_meta["titles"][1] if len(trap_meta["titles"]) > 1 else trap_meta["titles"][0]
            print(f"   Trap title pack: {len(trap_meta['titles'])} options")

        print(f"   Title EN: {meta.get('title')}")
        if meta.get("title_hi"):
            print(f"   Title HI: {meta.get('title_hi')}")

    print(f"▶ Generating {args.mode} video (theme={args.theme}) → {args.out}")
    opening = opening_label_from_game(game)
    if opening:
        print(f"   Opening: {opening}")
    show_bar = not getattr(args, "no_eval_bar", False)
    if args.mode == "silent":
        create_silent_video(
            analysis, args.out, move_duration=args.duration, theme=args.theme,
            white_name=white, black_name=black,
            white_photo=wp, black_photo=bp, white_flag=wf, black_flag=bf,
            opening_text=opening or None, show_eval_bar=show_bar,
            clock_text=(args.clock or None) or load_agent_config().get("clock"),
            bg_music=getattr(args, "bg_music", False) or load_agent_config().get("bg_music"),
            zoom_key_moments=True,
            watermark=(args.watermark or load_agent_config().get("watermark") or None),
            intro_card=not getattr(args, "no_intro", False),
            elo_badge=(trap_meta or {}).get("elo") if trap_meta else None,
            viral_hook=(args.viral_hook or (
                f"{(trap_meta or {}).get('name', '')}!".upper() if trap_meta else None
            )),
            next_trap=args.next_trap or (
                next_trap_suggestion((trap_meta or {}).get("key", "")) if trap_meta else ""
            ),
            refutation_key=(
                (trap_meta or {}).get("key")
                if trap_meta and (trap_meta or {}).get("has_refutation")
                and not getattr(args, "no_refutation", False)
                else None
            ),
        )
    else:
        commentary_lines = None
        voice = "hi-IN-MadhurNeural" if getattr(args, "lang", "en") == "hi" else "en-US-ChristopherNeural"
        if getattr(args, "gemini", False):
            print(f"▶ Gemini commentary lines ({GEMINI_MODEL}, lang={args.lang})…")
            try:
                commentary_lines = generate_commentary_lines_gemini(
                    analysis, white, black, lang=args.lang, format=args.format,
                )
                print(f"   {len(commentary_lines)} lines ready")
            except Exception as e:
                print(f"⚠️ Gemini commentary failed ({e}), using move names")
        create_commentary_video(
            analysis, args.out, move_duration=args.duration, theme=args.theme,
            white_name=white, black_name=black,
            white_photo=wp, black_photo=bp, white_flag=wf, black_flag=bf,
            commentary_lines=commentary_lines, voice=voice,
        )

    # Auto reels for traps
    if trap_meta and not getattr(args, "reels", False):
        args.reels = True
        print("▶ Auto Reels 9:16 for trap content")

    if getattr(args, "shorts_clip", False):
        shorts_out = str(Path(args.out).with_name(Path(args.out).stem + "_shorts.mp4"))
        print(f"▶ Shorts climax clip → {shorts_out}")
        create_shorts_clip(
            analysis, shorts_out, move_duration=min(2.5, args.duration),
            theme=args.theme, white_name=white, black_name=black,
            white_photo=wp, black_photo=bp, white_flag=wf, black_flag=bf,
        )
        print(f"✅ Shorts: {shorts_out}")

    if getattr(args, "reels", False):
        reels_out = str(Path(args.out).with_name(Path(args.out).stem + "_reels.mp4"))
        print(f"▶ Reels/TikTok 9:16 → {reels_out}")
        export_reels_vertical(
            analysis, reels_out, move_duration=min(2.2, args.duration),
            theme=args.theme, white_name=white, black_name=black,
            white_photo=wp, black_photo=bp, white_flag=wf, black_flag=bf,
            clock_text=(args.clock or None),
            voice=getattr(args, "shorts_voice", False) or bool(trap_meta),
            hook_line=(
                f"{(trap_meta or {}).get('name', 'This trap')} still works!"
                if trap_meta else (args.viral_hook or "Watch this!")
            ),
            max_seconds=getattr(args, "max_shorts", 40.0) or 40.0,
        )
        print(f"✅ Reels: {reels_out}")

    if getattr(args, "log_file", ""):
        append_drive_log(args.log_file, {
            "file": args.out, "white": white, "black": black,
            "mode": args.mode, "clock": args.clock,
        })
        print(f"✅ Log: {args.log_file}")

    if getattr(args, "discord_webhook", ""):
        post_discord_log(args.discord_webhook, f"{white} vs {black}", args.out, args.mode)

    if getattr(args, "compress_tg", False):
        compressed = compress_video_for_telegram(args.out)
        if compressed != args.out:
            print(f"✅ Compressed for Telegram: {compressed}")
            args.out = compressed

    if trap_meta and getattr(args, "meta", False):
        try:
            # enrich last meta if present
            pass
        except Exception:
            pass
    print(f"✅ Done! Video saved: {args.out}")
    if thumb_paths:
        for tp in thumb_paths:
            print(f"   Thumbnail: {tp}")


if __name__ == "__main__":
    main()
