"""
Chess64 Video Tool — FastAPI web service
Wraps chess_video_agent_v2 for Railway / local use.

Supports:
  - Paste PGN (local games)
  - Upload .pgn file
  - Built-in trap library / trap of the day
  - Long + Shorts + Reels outputs
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

# Agent lives one level up from webapp/
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault("STOCKFISH_PATH", os.environ.get("STOCKFISH_PATH", "/usr/local/bin/stockfish"))

from chess_video_agent_v2 import (  # noqa: E402
    analyze_game,
    create_shorts_clip,
    create_silent_video,
    create_viral_thumbnails_both,
    display_name_for,
    export_reels_vertical,
    generate_youtube_metadata,
    load_agent_config,
    load_game,
    list_traps,
    opening_label_from_game,
    resolve_player_assets,
    resolve_trap,
    save_youtube_metadata,
    scan_trending_suggestions,
    trap_of_the_day,
)

JOBS_DIR = Path(__file__).resolve().parent / "jobs"
JOBS_DIR.mkdir(parents=True, exist_ok=True)

MAX_CONCURRENT = int(os.environ.get("MAX_CONCURRENT_JOBS", "2"))
_sem = asyncio.Semaphore(MAX_CONCURRENT)

# in-memory job index (restart clears; files remain on disk)
JOBS: Dict[str, Dict[str, Any]] = {}

app = FastAPI(title="Chess64 Video Tool", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

static_dir = Path(__file__).resolve().parent / "static"
static_dir.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


def _job_path(job_id: str) -> Path:
    return JOBS_DIR / job_id


def _update(job_id: str, **kwargs):
    if job_id in JOBS:
        JOBS[job_id].update(kwargs)
        JOBS[job_id]["updated"] = datetime.utcnow().isoformat() + "Z"
        # persist status
        try:
            (_job_path(job_id) / "status.json").write_text(
                json.dumps(JOBS[job_id], indent=2), encoding="utf-8"
            )
        except Exception:
            pass


async def _run_job(
    job_id: str,
    pgn_text: str,
    mode: str = "silent",
    make_shorts: bool = True,
    make_reels: bool = True,
    make_thumbs: bool = True,
    duration: float = 3.0,
    watermark: str = "",
    clock: str = "10+0",
    trap_key: Optional[str] = None,
    max_shorts: float = 40.0,
):
    async with _sem:
        job_dir = _job_path(job_id)
        job_dir.mkdir(parents=True, exist_ok=True)
        try:
            _update(job_id, status="running", progress="Loading game…", percent=5)
            trap_meta = None
            if trap_key:
                pgn_text, trap_meta = await asyncio.to_thread(resolve_trap, trap_key)

            (job_dir / "input.pgn").write_text(pgn_text, encoding="utf-8")
            game = await asyncio.to_thread(load_game, pgn_text)
            white_raw = game.headers.get("White", "White")
            black_raw = game.headers.get("Black", "Black")
            white = display_name_for(white_raw)
            black = display_name_for(black_raw)

            _update(job_id, progress=f"Analyzing {white} vs {black}…", percent=15, white=white, black=black)
            analysis = await asyncio.to_thread(analyze_game, game, depth=10)
            opening = opening_label_from_game(game)

            cfg = load_agent_config()
            wm = watermark or cfg.get("watermark") or "@Chess64"
            clk = clock or cfg.get("clock") or "10+0"

            _update(job_id, progress="Resolving photos…", percent=25)
            wp, wf = await asyncio.to_thread(resolve_player_assets, white)
            bp, bf = await asyncio.to_thread(resolve_player_assets, black)

            long_path = job_dir / "long.mp4"
            _update(job_id, progress="Rendering long video…", percent=35)
            await asyncio.to_thread(
                create_silent_video,
                analysis,
                str(long_path),
                move_duration=duration,
                theme=cfg.get("theme") or "green",
                white_name=white,
                black_name=black,
                white_photo=wp,
                black_photo=bp,
                white_flag=wf,
                black_flag=bf,
                opening_text=opening or None,
                show_eval_bar=True,
                clock_text=clk,
                watermark=wm,
                intro_card=True,
                elo_badge=(trap_meta or {}).get("elo") if trap_meta else None,
                viral_hook=(
                    f"{(trap_meta or {}).get('name', '')}!".upper() if trap_meta else None
                ),
                next_trap="",
                refutation_key=(
                    (trap_meta or {}).get("key")
                    if trap_meta and (trap_meta or {}).get("has_refutation")
                    else None
                ),
            )

            files = {"long": "long.mp4"}

            if make_shorts:
                _update(job_id, progress="Rendering Shorts…", percent=60)
                shorts_path = job_dir / "shorts.mp4"
                await asyncio.to_thread(
                    create_shorts_clip,
                    analysis,
                    str(shorts_path),
                    move_duration=min(2.5, duration),
                    theme=cfg.get("theme") or "green",
                    white_name=white,
                    black_name=black,
                    white_photo=wp,
                    black_photo=bp,
                    white_flag=wf,
                    black_flag=bf,
                )
                files["shorts"] = "shorts.mp4"

            if make_reels:
                _update(job_id, progress="Rendering Reels 9:16…", percent=75)
                reels_path = job_dir / "reels.mp4"
                await asyncio.to_thread(
                    export_reels_vertical,
                    analysis,
                    str(reels_path),
                    move_duration=min(2.2, duration),
                    theme=cfg.get("theme") or "green",
                    white_name=white,
                    black_name=black,
                    white_photo=wp,
                    black_photo=bp,
                    white_flag=wf,
                    black_flag=bf,
                    clock_text=clk,
                    voice=bool(trap_meta),
                    hook_line=(
                        f"{(trap_meta or {}).get('name', 'This trap')} still works!"
                        if trap_meta
                        else "Watch this game!"
                    ),
                    max_seconds=max_shorts,
                )
                files["reels"] = "reels.mp4"

            if make_thumbs:
                _update(job_id, progress="Thumbnails…", percent=88)
                try:
                    thumbs = await asyncio.to_thread(
                        create_viral_thumbnails_both,
                        analysis,
                        str(job_dir / "thumb"),
                        2,
                        white_name=white,
                        black_name=black,
                        white_photo=wp,
                        black_photo=bp,
                        white_flag=wf,
                        black_flag=bf,
                    )
                    files["thumbs"] = [Path(p).name for p in (thumbs or []) if Path(p).exists()]
                except Exception as e:
                    print("thumb fail", e)

            _update(job_id, progress="Metadata…", percent=94)
            try:
                meta = generate_youtube_metadata(game, analysis, white, black, platform_hint="chesscom")
                if trap_meta and trap_meta.get("titles"):
                    meta["title_options"] = list(trap_meta["titles"])[:5]
                    meta["title"] = trap_meta["titles"][0]
                save_youtube_metadata(meta, str(job_dir / "meta"))
                files["meta"] = "meta_youtube.json"
            except Exception as e:
                print("meta fail", e)

            _update(
                job_id,
                status="done",
                progress="Ready",
                percent=100,
                files=files,
            )
        except Exception as e:
            traceback.print_exc()
            _update(job_id, status="error", progress=str(e), percent=0, error=str(e))


@app.get("/", response_class=HTMLResponse)
async def index():
    html = (static_dir / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)


@app.get("/api/health")
async def health():
    return {
        "ok": True,
        "stockfish": os.environ.get("STOCKFISH_PATH"),
        "jobs": len(JOBS),
    }


@app.get("/api/traps")
async def api_traps():
    traps = list_traps()
    trend = scan_trending_suggestions()
    return {"traps": traps, "trend": trend, "trap_of_day": trap_of_the_day()}


@app.post("/api/generate")
async def api_generate(
    background_tasks: BackgroundTasks,
    pgn: str = Form(""),
    trap: str = Form(""),
    trap_of_day: str = Form(""),
    duration: float = Form(3.0),
    watermark: str = Form("@Chess64"),
    clock: str = Form("10+0"),
    make_shorts: str = Form("1"),
    make_reels: str = Form("1"),
    make_thumbs: str = Form("1"),
    max_shorts: float = Form(40.0),
    file: Optional[UploadFile] = File(None),
):
    """
    Accept:
      - pgn text (local game paste)
      - .pgn file upload (local game file)
      - trap key or trap_of_day=1
    Produces long + optional shorts/reels.
    """
    pgn_text = (pgn or "").strip()
    trap_key = (trap or "").strip() or None

    if trap_of_day in ("1", "true", "yes", "on"):
        trap_key = trap_of_the_day()

    if file is not None and file.filename:
        raw = await file.read()
        try:
            pgn_text = raw.decode("utf-8")
        except UnicodeDecodeError:
            pgn_text = raw.decode("latin-1")

    if not pgn_text and not trap_key:
        raise HTTPException(400, "Provide PGN text, upload a .pgn file, or select a trap")

    if trap_key and not pgn_text:
        # placeholder; job resolves trap
        pgn_text = ""

    job_id = uuid.uuid4().hex[:12]
    job_dir = _job_path(job_id)
    job_dir.mkdir(parents=True, exist_ok=True)

    JOBS[job_id] = {
        "id": job_id,
        "status": "queued",
        "progress": "Queued",
        "percent": 0,
        "created": datetime.utcnow().isoformat() + "Z",
        "trap": trap_key,
    }

    background_tasks.add_task(
        _run_job,
        job_id,
        pgn_text,
        "silent",
        make_shorts in ("1", "true", "yes", "on"),
        make_reels in ("1", "true", "yes", "on"),
        make_thumbs in ("1", "true", "yes", "on"),
        float(duration),
        watermark,
        clock,
        trap_key,
        float(max_shorts),
    )

    return {"job_id": job_id, "status": "queued"}


@app.get("/api/status/{job_id}")
async def api_status(job_id: str):
    if job_id in JOBS:
        return JOBS[job_id]
    # recover from disk
    status_file = _job_path(job_id) / "status.json"
    if status_file.exists():
        return json.loads(status_file.read_text(encoding="utf-8"))
    raise HTTPException(404, "Job not found")


@app.get("/api/download/{job_id}/{name}")
async def api_download(job_id: str, name: str):
    allowed = {
        "long": "long.mp4",
        "shorts": "shorts.mp4",
        "reels": "reels.mp4",
        "meta": "meta_youtube.json",
        "pgn": "input.pgn",
    }
    # thumbs: thumb_16x9.jpg style
    job_dir = _job_path(job_id)
    if name in allowed:
        path = job_dir / allowed[name]
    elif name.startswith("thumb") and name.endswith((".jpg", ".png", ".jpeg")):
        path = job_dir / name
    else:
        raise HTTPException(400, "Invalid file name")

    if not path.exists():
        # try glob for thumbs
        if name == "thumb":
            cands = list(job_dir.glob("thumb*.jpg")) + list(job_dir.glob("*.jpg"))
            if cands:
                path = cands[0]
            else:
                raise HTTPException(404, "File not ready")
        else:
            raise HTTPException(404, "File not ready")

    media = "video/mp4" if path.suffix == ".mp4" else "application/octet-stream"
    return FileResponse(path, media_type=media, filename=path.name)


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "8080"))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
