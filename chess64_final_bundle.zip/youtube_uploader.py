#!/usr/bin/env python3
"""
YouTube Data API v3 uploader for Chess Video Agent.
Requires OAuth client secrets (Desktop app) from Google Cloud Console.

Setup:
  1. https://console.cloud.google.com/ → create project
  2. Enable "YouTube Data API v3"
  3. OAuth consent screen → External (or Internal)
  4. Credentials → Create OAuth client ID → Desktop app
  5. Download JSON → save as client_secrets.json next to this script
  6. First run opens browser to authorize → token.json is saved

Env (optional):
  YOUTUBE_CLIENT_SECRETS=/path/to/client_secrets.json
  YOUTUBE_TOKEN=/path/to/token.json
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

SCRIPT_DIR = Path(__file__).resolve().parent
CLIENT_SECRETS = Path(
    os.environ.get("YOUTUBE_CLIENT_SECRETS", str(SCRIPT_DIR / "client_secrets.json"))
)
TOKEN_PATH = Path(os.environ.get("YOUTUBE_TOKEN", str(SCRIPT_DIR / "token.json")))

SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube",
]


def get_youtube_service():
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    creds = None
    if TOKEN_PATH.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_PATH), SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not CLIENT_SECRETS.exists():
                raise FileNotFoundError(
                    f"Missing {CLIENT_SECRETS}\n"
                    "Download OAuth Desktop client JSON from Google Cloud Console "
                    "and save as client_secrets.json"
                )
            flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRETS), SCOPES)
            # local server works on desktop; for headless VPS use run_console
            try:
                creds = flow.run_local_server(port=0)
            except Exception:
                creds = flow.run_console()
        TOKEN_PATH.write_text(creds.to_json(), encoding="utf-8")
    return build("youtube", "v3", credentials=creds)


def add_to_playlist(youtube, video_id: str, playlist_id: str) -> None:
    if not playlist_id or not video_id:
        return
    youtube.playlistItems().insert(
        part="snippet",
        body={
            "snippet": {
                "playlistId": playlist_id,
                "resourceId": {"kind": "youtube#video", "videoId": video_id},
            }
        },
    ).execute()


def upload_video(
    video_path: str,
    title: str,
    description: str = "",
    tags: Optional[list] = None,
    category_id: str = "20",  # Gaming
    privacy: str = "private",  # private | unlisted | public
    thumbnail_path: Optional[str] = None,
    publish_at: Optional[str] = None,
    playlist_id: Optional[str] = None,
) -> dict:
    """
    Upload MP4 to YouTube. Returns {id, url, title, privacy}.
    publish_at: ISO8601 UTC e.g. 2026-08-20T15:00:00Z (forces private until then)
    playlist_id: optional playlist to add after upload
    """
    from googleapiclient.http import MediaFileUpload

    path = Path(video_path)
    if not path.exists():
        raise FileNotFoundError(video_path)

    youtube = get_youtube_service()
    status = {
        "privacyStatus": privacy if privacy in ("private", "unlisted", "public") else "private",
        "selfDeclaredMadeForKids": False,
    }
    if publish_at:
        # Scheduled publish requires private
        status["privacyStatus"] = "private"
        status["publishAt"] = publish_at
    body = {
        "snippet": {
            "title": (title or path.stem)[:100],
            "description": (description or "")[:5000],
            "tags": (tags or [])[:30],
            "categoryId": category_id,
        },
        "status": status,
    }
    media = MediaFileUpload(str(path), mimetype="video/mp4", resumable=True, chunksize=1024 * 1024)
    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"  Upload {int(status.progress() * 100)}%")

    video_id = response.get("id")
    # Optional thumbnail
    if thumbnail_path and Path(thumbnail_path).exists() and video_id:
        try:
            youtube.thumbnails().set(
                videoId=video_id,
                media_body=MediaFileUpload(thumbnail_path, mimetype="image/jpeg"),
            ).execute()
        except Exception as e:
            print(f"  Thumbnail set failed (may need channel verification): {e}")

    if playlist_id and video_id:
        try:
            add_to_playlist(youtube, video_id, playlist_id)
        except Exception as e:
            print(f"  Playlist add failed: {e}")

    return {
        "id": video_id,
        "url": f"https://youtu.be/{video_id}",
        "title": body["snippet"]["title"],
        "privacy": body["status"]["privacyStatus"],
        "publish_at": publish_at,
        "playlist_id": playlist_id,
    }


def meta_from_youtube_txt(txt_path: str) -> dict:
    """Best-effort parse of our *_youtube.txt into title/description/tags."""
    p = Path(txt_path)
    if not p.exists():
        return {}
    text = p.read_text(encoding="utf-8", errors="replace")
    title = ""
    description = ""
    tags = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line in ("TITLE:", "TITLE (long form):") and i + 1 < len(lines):
            title = lines[i + 1].strip()
        if line == "DESCRIPTION:" and i + 1 < len(lines):
            chunk = []
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith("---"):
                if lines[j].strip() in ("HASHTAGS:", "TAGS (YouTube tags field):", "--- HINDI"):
                    break
                if lines[j].strip().startswith("---"):
                    break
                chunk.append(lines[j])
                j += 1
            description = "\n".join(chunk).strip()
        if line.startswith("TAGS (YouTube tags field):") and i + 1 < len(lines):
            tags = [t.strip() for t in lines[i + 1].split(",") if t.strip()]
        i += 1
    return {"title": title, "description": description, "tags": tags}


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="Upload video to YouTube")
    ap.add_argument("video")
    ap.add_argument("--title", default="")
    ap.add_argument("--description", default="")
    ap.add_argument("--privacy", default="private", choices=["private", "unlisted", "public"])
    ap.add_argument("--thumb", default=None)
    ap.add_argument("--meta-txt", default=None, help="path to *_youtube.txt")
    ap.add_argument("--playlist", default=None)
    ap.add_argument("--publish-at", default=None, help="ISO8601 UTC")
    args = ap.parse_args()
    meta = meta_from_youtube_txt(args.meta_txt) if args.meta_txt else {}
    title = args.title or meta.get("title") or Path(args.video).stem
    desc = args.description or meta.get("description") or ""
    tags = meta.get("tags") or []
    r = upload_video(args.video, title, desc, tags=tags, privacy=args.privacy, thumbnail_path=args.thumb, publish_at=args.publish_at, playlist_id=args.playlist)
    print(json.dumps(r, indent=2))



def post_community(text: str) -> dict:
    """
    YouTube community post (limited API support).
    Uses youtube.activities.insert is not available for community posts via public API.
    Workaround: return a ready-to-paste payload and optional Studio deep-link hint.
    Full automated community posts require unofficial methods; we keep official path honest.
    """
    return {
        "status": "manual",
        "text": text[:1500],
        "hint": "Paste in YouTube Studio → Community (API has no stable public endpoint for all channels).",
    }
