#!/usr/bin/env python3
"""
Watch a folder for new .pgn files and auto-run the Chess Video Agent.

Usage:
  python watch_folder.py ./inbox --out-dir ./out --mode silent --shorts-clip --thumbnail --meta

Optional cron (daily 9am):
  0 9 * * * cd /path/to/agent && ./venv/bin/python watch_folder.py ./inbox --once --out-dir ./out --shorts-clip --thumbnail --meta
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
AGENT = SCRIPT_DIR / "chess_video_agent_v2.py"


def process_pgn(pgn: Path, out_dir: Path, extra_args: list) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / (pgn.stem + ".mp4")
    done_marker = out_dir / (pgn.stem + ".done")
    if done_marker.exists():
        print(f"skip (done): {pgn.name}")
        return
    cmd = [sys.executable, str(AGENT), str(pgn), "--out", str(out)] + extra_args
    print("RUN:", " ".join(cmd))
    r = subprocess.run(cmd)
    if r.returncode == 0:
        done_marker.write_text("ok\n", encoding="utf-8")
        # move processed pgn aside
        processed = pgn.parent / "processed"
        processed.mkdir(exist_ok=True)
        pgn.rename(processed / pgn.name)
        print(f"✅ {pgn.name} → {out}")
    else:
        print(f"❌ failed: {pgn.name} code={r.returncode}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inbox", type=Path, help="Folder to watch for .pgn")
    ap.add_argument("--out-dir", type=Path, default=Path("./out"))
    ap.add_argument("--once", action="store_true", help="Process current files and exit")
    ap.add_argument("--poll", type=float, default=5.0, help="Seconds between scans")
    ap.add_argument("--mode", default="silent", choices=["silent", "commentary"])
    ap.add_argument("--shorts-clip", action="store_true")
    ap.add_argument("--thumbnail", action="store_true")
    ap.add_argument("--meta", action="store_true")
    ap.add_argument("--gemini", action="store_true")
    ap.add_argument("--thumb-ab", type=int, default=1)
    ap.add_argument("--duration", type=float, default=5.0)
    args = ap.parse_args()

    extra = ["--mode", args.mode, "--duration", str(args.duration), "--thumb-ab", str(args.thumb_ab)]
    if args.shorts_clip:
        extra.append("--shorts-clip")
    if args.thumbnail:
        extra.append("--thumbnail")
    if args.meta:
        extra.append("--meta")
    if args.gemini:
        extra.append("--gemini")

    args.inbox.mkdir(parents=True, exist_ok=True)
    print(f"Watching {args.inbox.resolve()} → {args.out_dir.resolve()}")

    while True:
        pgns = sorted(args.inbox.glob("*.pgn"))
        for pgn in pgns:
            process_pgn(pgn, args.out_dir, extra)
        if args.once:
            break
        time.sleep(args.poll)


if __name__ == "__main__":
    main()
