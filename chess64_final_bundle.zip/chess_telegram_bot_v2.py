#!/usr/bin/env python3
"""
Chess Video Agent — Telegram Bot
--------------------------------
Commands:
  /start  /help
  /silent <player>     Chess.com online decisive
  /lichess <player>    Lichess online
  /offline <player>    Offline/FIDE-style only
  /pgn                 then paste PGN
  /duration <sec>      move duration
  /theme green|brown|blue|purple

After video is ready you get TWO buttons:
  📤 Send here (Telegram)  — download & manual YouTube upload
  ▶️ Upload to YouTube     — direct API upload (private by default)

Env:
  TELEGRAM_BOT_TOKEN=...
  ALLOWED_USER_IDS=123,456   (optional)
  GEMINI_API_KEY=...         (optional, for richer meta/commentary)
  YOUTUBE_CLIENT_SECRETS=client_secrets.json
  YOUTUBE_TOKEN=token.json
  YOUTUBE_PRIVACY=private    (private|unlisted|public)
"""

from __future__ import annotations

import asyncio
import os
import shutil
import tempfile
import traceback
import uuid
from pathlib import Path

from telegram import Update, InputFile, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

from chess_video_agent_v2 import (
    load_game,
    analyze_game,
    create_silent_video,
    create_shorts_clip,
    export_reels_vertical,
    opening_label_from_game,
    create_viral_thumbnails_both,
    generate_youtube_metadata,
    generate_youtube_metadata_gemini,
    save_youtube_metadata,
    fetch_latest_decisive_pgn,
    resolve_player_assets,
    display_name_for,
    load_agent_config,
    resolve_trap,
    list_traps,
    scan_trending_suggestions,
    trap_of_the_day,
    compress_video_for_telegram,
    GEMINI_API_KEY,
)

SCRIPT_DIR = Path(__file__).resolve().parent
JOBS_DIR = SCRIPT_DIR / "bot_jobs"
JOBS_DIR.mkdir(exist_ok=True)

DEFAULT_DURATION = 7.0
DEFAULT_THEME = "green"
DEFAULT_DEPTH = 12
MAX_MOVES_FOR_BOT = 60

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
ALLOWED = {
    int(x.strip())
    for x in os.environ.get("ALLOWED_USER_IDS", "").split(",")
    if x.strip().isdigit()
}
YOUTUBE_PRIVACY = os.environ.get("YOUTUBE_PRIVACY", "private").strip().lower()


def _allowed(user_id: int) -> bool:
    return (not ALLOWED) or (user_id in ALLOWED)


def _user_settings(context: ContextTypes.DEFAULT_TYPE):
    return {
        "duration": float(context.user_data.get("duration", DEFAULT_DURATION)),
        "theme": context.user_data.get("theme", DEFAULT_THEME),
    }


def _job_keyboard(job_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "📤 Send on Telegram (manual)",
                    callback_data=f"tg:{job_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "📱 Send Reels 9:16",
                    callback_data=f"reels:{job_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "🔒 YouTube PRIVATE (review)",
                    callback_data=f"ytpriv:{job_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "✅ Approve → YouTube PUBLIC",
                    callback_data=f"ytpub:{job_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "▶️ YouTube UNLISTED",
                    callback_data=f"ytunlist:{job_id}",
                )
            ],
        ]
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        await update.message.reply_text("Access denied.")
        return
    await update.message.reply_text(
        "♟️ *Chess Video Agent Bot*\n\n"
        "Online Chess.com:\n`/silent Magnus Carlsen`\n\n"
        "Online Lichess:\n`/lichess Magnus Carlsen`\n\n"
        "Offline / FIDE-style:\n`/offline Magnus Carlsen`\n\n"
        "Custom PGN: send `.pgn` file or `/pgn` then paste\n\n"
        "After video is ready you choose:\n"
        "• *Send on Telegram* → manual YouTube upload\n"
        "• *Upload to YouTube* → direct API (default private)\n\n"
        "`/trapofday`  `/trap stafford`  `/traps`  `/trend`\n`/duration 5`  `/theme green`  `/help`",
        parse_mode="Markdown",
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


async def set_duration(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    try:
        val = float(context.args[0])
        if not (1.5 <= val <= 20):
            raise ValueError
        context.user_data["duration"] = val
        await update.message.reply_text(f"✅ Duration set to {val}s per move")
    except Exception:
        await update.message.reply_text("Usage: `/duration 7`", parse_mode="Markdown")


async def set_theme(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    theme = (context.args[0] if context.args else "").lower()
    if theme not in ("green", "brown", "blue", "purple"):
        await update.message.reply_text("Usage: `/theme green|brown|blue|purple`", parse_mode="Markdown")
        return
    context.user_data["theme"] = theme
    await update.message.reply_text(f"✅ Theme set to {theme}")


async def _build_and_send(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    pgn_text: str,
    platform: str = "chesscom",
):
    status = await update.message.reply_text("⏳ Loading game…")
    settings = _user_settings(context)
    job_id = uuid.uuid4().hex[:12]
    job_dir = JOBS_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    video_path = job_dir / "game.mp4"
    meta_base = job_dir / "game"

    try:
        await status.edit_text("⏳ Analyzing with Stockfish…")
        game = await asyncio.to_thread(load_game, pgn_text)
        white_raw = game.headers.get("White", "White")
        black_raw = game.headers.get("Black", "Black")
        white = display_name_for(white_raw, platform=platform)
        black = display_name_for(black_raw, platform=platform)

        analysis = await asyncio.to_thread(analyze_game, game, DEFAULT_DEPTH)
        if len(analysis) > MAX_MOVES_FOR_BOT + 1:
            analysis = analysis[: MAX_MOVES_FOR_BOT + 1]
            await status.edit_text(
                f"⏳ Long game — first {MAX_MOVES_FOR_BOT} moves…\n{white} vs {black}"
            )
        else:
            await status.edit_text(f"⏳ {white} vs {black}\n[1/5] Photos…")

        wp, wf = await asyncio.to_thread(resolve_player_assets, white)
        bp, bf = await asyncio.to_thread(resolve_player_assets, black)

        opening = opening_label_from_game(game)
        cfg = load_agent_config()
        await status.edit_text(f"⏳ {white} vs {black}\n[2/5] Rendering long video…")
        await asyncio.to_thread(
            create_silent_video,
            analysis,
            str(video_path),
            move_duration=settings["duration"],
            theme=settings["theme"],
            white_name=white,
            black_name=black,
            white_photo=wp,
            black_photo=bp,
            white_flag=wf,
            black_flag=bf,
            opening_text=opening or None,
            show_eval_bar=True,
            clock_text=os.environ.get("CHESS_CLOCK") or cfg.get("clock") or "10+0",
            watermark=cfg.get("watermark") or None,
            intro_card=True,
            bg_music=bool(cfg.get("bg_music")),
        )
        await status.edit_text(f"⏳ {white} vs {black}\n[3/5] Shorts + Reels…")
        shorts_path = job_dir / "shorts.mp4"
        await asyncio.to_thread(
            create_shorts_clip,
            analysis,
            str(shorts_path),
            move_duration=min(2.5, settings["duration"]),
            theme=settings["theme"],
            white_name=white,
            black_name=black,
            white_photo=wp,
            black_photo=bp,
            white_flag=wf,
            black_flag=bf,
        )
        reels_path = job_dir / "reels.mp4"
        await asyncio.to_thread(
            export_reels_vertical,
            analysis,
            str(reels_path),
            move_duration=min(2.2, settings["duration"]),
            theme=settings["theme"],
            white_name=white,
            black_name=black,
            white_photo=wp,
            black_photo=bp,
            white_flag=wf,
            black_flag=bf,
            clock_text=os.environ.get("CHESS_CLOCK", "10+0"),
        )

        await status.edit_text(f"⏳ {white} vs {black}\n[4/5] Thumbnails + SEO…")
        thumb_paths = await asyncio.to_thread(
            create_viral_thumbnails_both,
            analysis,
            str(job_dir / "thumb"),
            2,
            white_name=white,
            black_name=black,
            white_photo=wp,
            black_photo=bp,
            white_flag=wf,
            black_flag=bf,
            theme=settings["theme"],
        )

        # Metadata: Gemini if key present, else local
        try:
            if GEMINI_API_KEY:
                meta = await asyncio.to_thread(
                    generate_youtube_metadata_gemini, game, analysis, white, black, platform
                )
            else:
                meta = await asyncio.to_thread(
                    generate_youtube_metadata, game, analysis, white, black, platform
                )
        except Exception:
            meta = await asyncio.to_thread(
                generate_youtube_metadata, game, analysis, white, black, platform
            )
        meta_file = await asyncio.to_thread(save_youtube_metadata, meta, str(meta_base))

        # Save job index for callbacks
        index = {
            "video": str(video_path),
            "shorts": str(job_dir / "shorts.mp4"),
            "reels": str(job_dir / "reels.mp4"),
            "thumbs": thumb_paths,
            "meta_txt": meta_file,
            "meta_json": str(Path(str(meta_base) + "_youtube.json")),
            "title": meta.get("title") or f"{white} vs {black}",
            "title_hi": meta.get("title_hi") or "",
            "white": white,
            "black": black,
        }
        (job_dir / "index.json").write_text(
            __import__("json").dumps(index, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        await status.edit_text(
            f"✅ Ready: *{white}* vs *{black}*\n\n"
            f"📌 `{index['title']}`\n\n"
            f"Choose what to do:",
            parse_mode="Markdown",
            reply_markup=_job_keyboard(job_id),
        )
    except Exception as e:
        traceback.print_exc()
        await status.edit_text(f"❌ Error: {e}")
        shutil.rmtree(job_dir, ignore_errors=True)


async def on_job_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not _allowed(query.from_user.id):
        await query.edit_message_text("Access denied.")
        return

    data = query.data or ""
    if ":" not in data:
        return
    action, job_id = data.split(":", 1)
    job_dir = JOBS_DIR / job_id
    index_path = job_dir / "index.json"
    if not index_path.exists():
        await query.edit_message_text("❌ Job expired or not found. Generate again.")
        return

    import json

    index = json.loads(index_path.read_text(encoding="utf-8"))
    video = Path(index["video"])
    thumbs = [Path(t) for t in index.get("thumbs") or []]
    meta_txt = Path(index.get("meta_txt") or "")

    if action == "tg":
        await query.edit_message_text("📤 Sending video + thumbs + metadata on Telegram…")
        try:
            if meta_txt.exists():
                await context.bot.send_document(
                    chat_id=query.message.chat_id,
                    document=InputFile(open(meta_txt, "rb"), filename="youtube_metadata.txt"),
                    caption="Title / description / hashtags (manual upload)",
                )
            for tp in thumbs:
                if tp.exists():
                    await context.bot.send_photo(
                        chat_id=query.message.chat_id,
                        photo=InputFile(open(tp, "rb"), filename=tp.name),
                        caption=tp.name,
                    )
            if video.exists():
                size_mb = video.stat().st_size / (1024 * 1024)
                send_path = video
                if size_mb > 45:
                    await context.bot.send_message(
                        chat_id=query.message.chat_id,
                        text=f"⏳ Compressing {size_mb:.1f}MB for Telegram…",
                    )
                    send_path = Path(await asyncio.to_thread(compress_video_for_telegram, str(video)))
                await context.bot.send_video(
                    chat_id=query.message.chat_id,
                    video=InputFile(open(send_path, "rb"), filename="chess.mp4"),
                    caption=f"♟️ {index.get('white')} vs {index.get('black')}\nLong video — manual upload ready",
                    supports_streaming=True,
                )
            shorts = Path(index.get("shorts") or "")
            if shorts.exists():
                await context.bot.send_video(
                    chat_id=query.message.chat_id,
                    video=InputFile(open(shorts, "rb"), filename="shorts.mp4"),
                    caption="Shorts climax clip",
                    supports_streaming=True,
                )
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text="✅ Sent on Telegram. You can upload manually to YouTube.",
            )
        except Exception as e:
            traceback.print_exc()
            await context.bot.send_message(chat_id=query.message.chat_id, text=f"❌ Send failed: {e}")
        return

    if action == "reels":
        await query.edit_message_text("📱 Sending Reels 9:16…")
        reels = Path(index.get("reels") or "")
        try:
            if reels.exists():
                await context.bot.send_video(
                    chat_id=query.message.chat_id,
                    video=InputFile(open(reels, "rb"), filename="reels.mp4"),
                    caption="Reels / TikTok 9:16",
                    supports_streaming=True,
                )
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text="✅ Reels sent. Upload to Shorts / TikTok / IG.",
                )
            else:
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text="❌ Reels file missing — regenerate job.",
                )
        except Exception as e:
            traceback.print_exc()
            await context.bot.send_message(
                chat_id=query.message.chat_id, text=f"❌ Reels send failed: {e}"
            )
        return

    if action in ("ytpriv", "ytpub", "ytunlist"):
        privacy_map = {"ytpriv": "private", "ytpub": "public", "ytunlist": "unlisted"}
        privacy = privacy_map[action]
        await query.edit_message_text(
            f"▶️ Uploading to YouTube ({privacy})…\nThis may take a minute."
        )
        try:
            from youtube_uploader import upload_video, meta_from_youtube_txt

            meta = meta_from_youtube_txt(str(meta_txt)) if meta_txt.exists() else {}
            title = meta.get("title") or index.get("title") or "Chess Game"
            description = meta.get("description") or ""
            tags = meta.get("tags") or []
            thumb = None
            for tp in thumbs:
                if tp.exists() and "16x9" in tp.name:
                    thumb = str(tp)
                    break
            if not thumb and thumbs and thumbs[0].exists():
                thumb = str(thumbs[0])

            playlist_id = os.environ.get("YOUTUBE_PLAYLIST_ID", "").strip() or None
            publish_at = os.environ.get("YOUTUBE_PUBLISH_AT", "").strip() or None

            result = await asyncio.to_thread(
                upload_video,
                str(video),
                title,
                description,
                tags,
                "20",
                privacy,
                thumb,
                publish_at if privacy == "private" else None,
                playlist_id,
            )
            extra = ""
            if result.get("publish_at"):
                extra += f"\nSchedule: `{result['publish_at']}`"
            if result.get("playlist_id"):
                extra += f"\nPlaylist: `{result['playlist_id']}`"
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=(
                    f"✅ *Uploaded to YouTube*\n"
                    f"Title: `{result.get('title')}`\n"
                    f"Privacy: `{result.get('privacy')}`\n"
                    f"Link: {result.get('url')}"
                    + extra
                ),
                parse_mode="Markdown",
                disable_web_page_preview=False,
            )
            # Also offer shorts upload hint
            shorts = Path(index.get("shorts") or "")
            if shorts.exists():
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text=f"Shorts clip also ready in job folder: `{shorts.name}` (upload manually or re-run).",
                    parse_mode="Markdown",
                )
        except FileNotFoundError as e:
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=(
                    f"❌ YouTube setup missing:\n`{e}`\n\n"
                    "Add `client_secrets.json` + authorize once."
                ),
                parse_mode="Markdown",
            )
        except Exception as e:
            traceback.print_exc()
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"❌ YouTube upload failed: {e}",
            )
        return



async def cmd_silent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    player = " ".join(context.args).strip() if context.args else ""
    if not player:
        await update.message.reply_text("Usage: `/silent Magnus Carlsen`", parse_mode="Markdown")
        return
    status = await update.message.reply_text(
        f"🔎 Chess.com online: *{player}*…", parse_mode="Markdown"
    )
    try:
        pgn, meta = await asyncio.to_thread(fetch_latest_decisive_pgn, player, "chesscom")
        await status.edit_text(
            f"✅ {meta.get('white')} vs {meta.get('black')} — building…"
        )
        await _build_and_send(update, context, pgn, platform="chesscom")
    except Exception as e:
        await status.edit_text(f"❌ {e}")


async def cmd_lichess(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    player = " ".join(context.args).strip() if context.args else ""
    if not player:
        await update.message.reply_text("Usage: `/lichess Magnus Carlsen`", parse_mode="Markdown")
        return
    status = await update.message.reply_text(f"🔎 Lichess: *{player}*…", parse_mode="Markdown")
    try:
        pgn, meta = await asyncio.to_thread(fetch_latest_decisive_pgn, player, "lichess")
        await status.edit_text(
            f"✅ {meta.get('white')} vs {meta.get('black')} — building…"
        )
        await _build_and_send(update, context, pgn, platform="lichess")
    except Exception as e:
        await status.edit_text(f"❌ {e}")


async def cmd_offline(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    player = " ".join(context.args).strip() if context.args else ""
    if not player:
        await update.message.reply_text(
            "Usage: `/offline Magnus Carlsen`", parse_mode="Markdown"
        )
        return
    status = await update.message.reply_text(
        f"🔎 Offline/FIDE-style: *{player}*…", parse_mode="Markdown"
    )
    try:
        pgn, meta = await asyncio.to_thread(fetch_latest_decisive_pgn, player, "tournament")
        await status.edit_text(
            f"✅ {meta.get('white')} vs {meta.get('black')} — building…"
        )
        await _build_and_send(update, context, pgn, platform="chesscom")
    except Exception as e:
        await status.edit_text(f"❌ {e}")


async def cmd_pgn(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    context.user_data["expect_pgn"] = True
    await update.message.reply_text("Paste the full PGN text in the next message.")


async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    if not context.user_data.get("expect_pgn"):
        return
    text = (update.message.text or "").strip()
    if "[Event" not in text and "1." not in text:
        await update.message.reply_text("That does not look like PGN. Send PGN or /cancel")
        return
    context.user_data["expect_pgn"] = False
    await _build_and_send(update, context, text, platform="chesscom")


async def on_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    doc = update.message.document
    if not doc:
        return
    name = (doc.file_name or "").lower()
    if not (name.endswith(".pgn") or name.endswith(".txt")):
        await update.message.reply_text("Please send a .pgn file")
        return
    f = await doc.get_file()
    data = await f.download_as_bytearray()
    pgn = data.decode("utf-8", errors="replace")
    await _build_and_send(update, context, pgn, platform="chesscom")



async def cmd_traps(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    lines = ["📚 *Trap library:*\n"]
    for k, m in list_traps().items():
        lines.append(f"`{k}` — {m.get('name')} (~{m.get('elo')})")
    lines.append("\nUse `/trap stafford`")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_trend(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    lines = ["🔥 *Trending traps 2026:*\n"]
    for s in scan_trending_suggestions():
        lines.append(f"• *{s['name']}* (~{s['elo']}) — `/trap {s['key']}`")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")



async def cmd_trapofday(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    key = trap_of_the_day()
    status = await update.message.reply_text(f"🔥 Trap of the day: *{key}*…", parse_mode="Markdown")
    try:
        pgn, meta = await asyncio.to_thread(resolve_trap, key)
        await status.edit_text(
            f"✅ {meta.get('name')} (~{meta.get('elo')}) — building…"
        )
        await _build_and_send(update, context, pgn, platform="chesscom")
    except Exception as e:
        await status.edit_text(f"❌ {e}")


async def cmd_trap(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _allowed(update.effective_user.id):
        return
    name = " ".join(context.args).strip() if context.args else ""
    if not name:
        await update.message.reply_text(
            "Usage: `/trap stafford`\n`/traps` for list", parse_mode="Markdown"
        )
        return
    status = await update.message.reply_text(f"📚 Loading trap *{name}*…", parse_mode="Markdown")
    try:
        pgn, meta = await asyncio.to_thread(resolve_trap, name)
        await status.edit_text(
            f"✅ {meta.get('name')} (~{meta.get('elo')}) — building…"
        )
        await _build_and_send(update, context, pgn, platform="chesscom")
    except Exception as e:
        await status.edit_text(f"❌ {e}")


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["expect_pgn"] = False
    await update.message.reply_text("Cancelled.")


def main():
    if not TOKEN:
        print("Set TELEGRAM_BOT_TOKEN environment variable")
        raise SystemExit(1)

    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("silent", cmd_silent))
    app.add_handler(CommandHandler("lichess", cmd_lichess))
    app.add_handler(CommandHandler("offline", cmd_offline))
    app.add_handler(CommandHandler("pgn", cmd_pgn))
    app.add_handler(CommandHandler("duration", set_duration))
    app.add_handler(CommandHandler("theme", set_theme))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CommandHandler("trapofday", cmd_trapofday))
    app.add_handler(CommandHandler("trapoftheday", cmd_trapofday))
    app.add_handler(CommandHandler("trap", cmd_trap))
    app.add_handler(CommandHandler("traps", cmd_traps))
    app.add_handler(CommandHandler("trend", cmd_trend))
    app.add_handler(CallbackQueryHandler(on_job_button, pattern=r"^(tg|reels|ytpriv|ytpub|ytunlist):"))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))

    print("Bot starting (polling)…")
    print(f"YouTube privacy default: {YOUTUBE_PRIVACY}")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
